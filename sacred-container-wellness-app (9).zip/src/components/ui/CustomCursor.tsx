import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

/** Premium dual-layer cursor: dot + lagging ring. Desktop only. No sparkles (perf). */
export default function CustomCursor() {
  const [enabled, setEnabled] = useState(false);
  const [hovering, setHovering] = useState(false);
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const ringX = useSpring(x, { stiffness: 280, damping: 28, mass: 0.6 });
  const ringY = useSpring(y, { stiffness: 280, damping: 28, mass: 0.6 });

  useEffect(() => {
    const mq = window.matchMedia("(hover: hover) and (pointer: fine)");
    if (!mq.matches) return;
    setEnabled(true);
    document.body.classList.add("has-cursor");

    let rafId: number;
    let cx = -100, cy = -100;

    function move(e: MouseEvent) {
      cx = e.clientX; cy = e.clientY;
    }
    function tick() {
      x.set(cx); y.set(cy);
      rafId = requestAnimationFrame(tick);
    }
    function hover(e: MouseEvent) {
      const t = e.target as HTMLElement | null;
      setHovering(!!t && !!t.closest('button, a, [role="button"], input, label'));
    }

    rafId = requestAnimationFrame(tick);
    window.addEventListener("mousemove", move, { passive: true });
    window.addEventListener("mouseover", hover, { passive: true });

    return () => {
      cancelAnimationFrame(rafId);
      document.body.classList.remove("has-cursor");
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseover", hover);
    };
  }, [x, y]);

  if (!enabled) return null;

  return (
    <>
      {/* Dot — dəqiq mövqe */}
      <motion.span
        className="pointer-events-none fixed z-[9999]"
        style={{
          x, y,
          translateX: "-50%",
          translateY: "-50%",
          width: hovering ? 10 : 7,
          height: hovering ? 10 : 7,
          borderRadius: "50%",
          background: "var(--accent)",
          boxShadow: "0 0 8px rgba(251,206,177,0.7)",
          transition: "width 0.2s, height 0.2s",
        }}
      />
      {/* Ring — yavaş izləyir */}
      <motion.span
        className="pointer-events-none fixed z-[9998]"
        style={{
          x: ringX, y: ringY,
          translateX: "-50%",
          translateY: "-50%",
          width: hovering ? 36 : 28,
          height: hovering ? 36 : 28,
          borderRadius: "50%",
          border: "1.5px solid rgba(251,206,177,0.5)",
          transition: "width 0.25s, height 0.25s",
        }}
      />
    </>
  );
}
