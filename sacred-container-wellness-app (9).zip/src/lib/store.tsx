import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

/* =================== İNCİ — 30 GÜNLÜK PROQRAM =================== */

export type Gender = "woman" | "man";
export type AgeRange = "18-25" | "26-35" | "36-45" | "46-55" | "56+";
export type WeightRange = "40-60" | "60-80" | "80-100" | "100-120" | "120+";
export type HeightRange = "140-160" | "160-175" | "175-190" | "190+";
export type ActivityLevel = "sedentary" | "light" | "moderate" | "active";
export type ExerciseFrequency = "0" | "1-2" | "3-4" | "5-6" | "7";
export type ExerciseType = "none" | "walk" | "home" | "gym" | "cardio" | "other";
export type WorkLifestyle = "sitting" | "mixed" | "standing" | "heavy";
export type Restriction = "none" | "dairy-free" | "bread-free" | "meat-free" | "egg-free";

export interface Profile {
  gender: Gender;
  age: AgeRange;
  weight: WeightRange;
  height: HeightRange;
  activity: ActivityLevel;
  exerciseFrequency: ExerciseFrequency;
  exerciseType: ExerciseType;
  workLifestyle: WorkLifestyle;
  restriction: Restriction;
}

export type MealKey = "morning" | "snack" | "noon" | "evening";
export type MealSelections = Record<string, number>;

interface PersistedState {
  profile: Profile | null;
  onboarded: boolean;
  selections: Record<number, MealSelections>;
  weightNote: string;
}

interface Store extends PersistedState {
  profileSet: boolean;
  saveProfile: (p: Profile) => void;
  selectMeal: (day: number, key: string, id: number) => void;
  getSelection: (day: number, key: string) => number | undefined;
  setWeightNote: (note: string) => void;
}

const STORAGE_KEY = "inci-30gun-v26";

function defaultState(): PersistedState {
  return {
    profile: null,
    onboarded: false,
    selections: {},
    weightNote: "",
  };
}

function load(): PersistedState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw) as Partial<PersistedState>;
    const merged = { ...defaultState(), ...parsed };

    // Köhnə profildə bəzi sahələr olmaya bilər (upgrade senariusu).
    // Bütün yeni sahələrə defolt dəyər veririk — proqram yenidən ankete qayıtmasın.
    let profile = merged.profile ?? null;
    if (profile) {
      profile = {
        ...profile,
        restriction: profile.restriction ?? "none",
        exerciseFrequency: profile.exerciseFrequency ?? "1-2",
        exerciseType: profile.exerciseType ?? "none",
        workLifestyle: profile.workLifestyle ?? "mixed",
      };
    }

    // Kritik qoruma: onboarded=true amma profile=null olarsa → sıfırla.
    // Bu, məhz "proqram yenidən ankete başlayır" xətasının qarşısını alır.
    const onboarded = merged.onboarded && profile !== null;

    const clean: PersistedState = {
      profile,
      onboarded,
      selections: merged.selections ?? {},
      weightNote: merged.weightNote ?? "",
    };
    return clean;
  } catch {
    return defaultState();
  }
}

const StoreContext = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistedState>(load);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      /* storage unavailable */
    }
  }, [state]);

  const value = useMemo<Store>(() => {
    
    return {
      ...state,
      profileSet: !!state.profile,
            saveProfile: (p) => setState((s) => ({
        ...s,
        profile: p,
        onboarded: true,
      })),
      selectMeal: (day, key, id) =>
        setState((s) => {
          const cur = s.selections[day] ?? {};
          return {
            ...s,
            selections: { ...s.selections, [day]: { ...cur, [key]: id } },
          };
        }),
      getSelection: (day, key) =>
        state.selections[day]?.[key] ?? undefined,
      setWeightNote: (note) => setState((s) => ({ ...s, weightNote: note.slice(0, 100) })),
    };
  }, [state]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): Store {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
