import { motion, type HTMLMotionProps } from "framer-motion";
import { cn } from "@/utils/cn";
import { Tilt } from "@/components/ui/motion";

interface CardProps extends HTMLMotionProps<"div"> {
  hover?: boolean;
  tilt?: boolean;
  /** Adds a soft breathing accent glow around the card border on hover. */
  glow?: boolean;
  /** Plays a premium blur+scale entrance the first time the card mounts. */
  enter?: boolean;
  children: React.ReactNode;
}

export default function Card({
  hover = false,
  tilt = false,
  glow = false,
  enter = false,
  className,
  children,
  ...rest
}: CardProps) {
  const inner = (
    <motion.div
      className={cn(
        "glass",
        hover && "glass-hover",
        glow && "anim-magnet-pulse",
        enter && "anim-blur-in",
        "p-6",
        className
      )}
      {...rest}
    >
      {children}
    </motion.div>
  );

  if (tilt) {
    return (
      <Tilt intensity={6} className="[&>div]:will-change-transform">
        {inner}
      </Tilt>
    );
  }
  return inner;
}
