import type { Dish, MealSlot, DayMenu } from "@/lib/menuTemplates";

/* =====================================================================
   7 KALORİ QRUPUNUN HƏR BİRİ ÜÇÜN HƏQİQİ 30 GÜNLÜK MENYU
   Mənbə: istifadəçinin təqdim etdiyi elmi cəhətdən yoxlanmış menyu bazası.
   Hər gün, hər vaxt üçün 3 seçim var (istifadəçi 1-ni seçir).
   Bu fayl yalnız DATA saxlayır — məntiq groupMenus.ts-dədir.
   BÜTÜN 7 QRUP TAM VƏ HƏQİQİ 30 GÜNLÜK MENYU İLƏ MÖVCUDDUR.
==================================================================== */

export type CalorieGroupKey =
  | "1200_1299" | "1300_1399" | "1400_1499"
  | "1500_1599" | "1600_1699" | "1700_1799" | "1800_1899";

const GROUP_1200_1299: DayMenu[] = [
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 54 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 45 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 37 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 245, options: [
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 14 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 16 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 42 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 244, options: [
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 39 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 12 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 244, options: [
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 22 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 35 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 25 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 79 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 20 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 14 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 3 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 68 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 85 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 246, options: [
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 24 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 16 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 57 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 245, options: [
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 6 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 16 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 3 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 245, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 14 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 8 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 19 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 5 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 23 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 15 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 8 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 58 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 84 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 246, options: [
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 50 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 31 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 55 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 245, options: [
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 11 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 16 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 9 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 245, options: [
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 42 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 14 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 16 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 5 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 7 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 27 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 246, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 29 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 5 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 38 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 244, options: [
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 25 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 22 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 35 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 246, options: [
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 53 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 1 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 10 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 246, options: [
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 57 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 24 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 16 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 52 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 63 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 64 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 4 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 31 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 30 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 245, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 19 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 14 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 8 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 246, options: [
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 17 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 2 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 6 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 246, options: [
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 55 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 50 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 31 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 3 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 28 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 20 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 45 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 37 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 54 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 245, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 16 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 42 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 14 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 244, options: [
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 12 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 39 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 244, options: [
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 35 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 25 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 22 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 20 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 14 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 79 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 68 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 85 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 3 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 246, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 16 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 57 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 24 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 245, options: [
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 16 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 3 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 6 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 245, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 8 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 19 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 14 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 23 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 15 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 5 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 58 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 84 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 8 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 246, options: [
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 31 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 55 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 50 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 245, options: [
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 16 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 9 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 11 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 245, options: [
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 14 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 16 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 42 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 7 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 27 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 5 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 246, options: [
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 5 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 38 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 29 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 244, options: [
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 22 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 35 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 25 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 246, options: [
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 1 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 10 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 53 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 246, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 24 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 16 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 57 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 63 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 64 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 52 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 31 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 30 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 4 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 245, options: [
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 14 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 8 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 19 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 246, options: [
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 2 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 6 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 17 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 246, options: [
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 50 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 31 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 55 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 28 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 20 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 3 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 37 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 54 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 45 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 245, options: [
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 42 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 14 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 16 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 244, options: [
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 12 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 39 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 244, options: [
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 25 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 22 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 35 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 14 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 79 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 20 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 85 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 3 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 68 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 246, options: [
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 57 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 24 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 16 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 245, options: [
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 3 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 6 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 16 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 245, options: [
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 19 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 14 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 8 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 15 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 5 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 23 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 84 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 8 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 58 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 246, options: [
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 55 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 50 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 31 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 245, options: [
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 9 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 11 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 16 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 245, options: [
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 16 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 42 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 14 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 27 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 5 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 7 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 246, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 38 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 29 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 5 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 244, options: [
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 35 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 25 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 22 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 246, options: [
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 10 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 53 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 1 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 246, options: [
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 16 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 57 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 24 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 64 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 52 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 63 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 30 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 4 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 31 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 245, options: [
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 8 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 19 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 14 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 246, options: [
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 6 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 17 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 2 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 246, options: [
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 31 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 55 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 50 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 20 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 3 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 28 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 54 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 45 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 37 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 245, options: [
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 14 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 16 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 42 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 244, options: [
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 39 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 12 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 244, options: [
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 22 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 35 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 25 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 79 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 20 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 14 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 3 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 68 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 85 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 246, options: [
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 24 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 16 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 57 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 245, options: [
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 6 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 16 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 3 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 245, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 14 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 8 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 19 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 5 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 23 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 15 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 8 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 58 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 84 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 246, options: [
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 50 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 31 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 55 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 245, options: [
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 11 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 16 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 9 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 245, options: [
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 42 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 14 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 16 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 5 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 7 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 27 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 246, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 29 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 5 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 38 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 244, options: [
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 25 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 22 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 35 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 246, options: [
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 53 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 1 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 10 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 246, options: [
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 57 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 24 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 16 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 52 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 63 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 64 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 4 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 31 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 30 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 245, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 19 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 14 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 8 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 246, options: [
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 17 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 2 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 6 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 246, options: [
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 55 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 50 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 31 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 3 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 28 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 20 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 245, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 45 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 37 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 54 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 245, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 16 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 42 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 14 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 244, options: [
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 12 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 39 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 244, options: [
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 35 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 25 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 22 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 245, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 20 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 14 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 79 q çörək" },
    ] },
  ],
];

const GROUP_1300_1399: DayMenu[] = [
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 45 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 76 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 11 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 23 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 57 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 65 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 266, options: [
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 47 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 10 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 23 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 43 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 49 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 33 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 22 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 27 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 13 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 266, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 92 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 53 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 62 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 23 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 31 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 30 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 266, options: [
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 11 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 9 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 19 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 15 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 38 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 22 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 31 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 1 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 28 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 38 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 65 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 16 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 26 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 63 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 22 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 265, options: [
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 13 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 4 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 14 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 65 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 23 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 57 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 264, options: [
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 35 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 5 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 86 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 5 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 37 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 15 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 33 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 43 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 49 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 264, options: [
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 17 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 24 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 30 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 23 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 31 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 14 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 59 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 87 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 12 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 11 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 61 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 22 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 15 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 38 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 264, options: [
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 16 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 8 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 60 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 22 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 26 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 63 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 11 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 13 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 71 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 76 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 11 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 45 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 57 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 65 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 23 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 266, options: [
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 10 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 23 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 47 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 49 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 33 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 43 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 27 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 13 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 22 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 266, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 53 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 62 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 92 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 31 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 30 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 23 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 266, options: [
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 9 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 19 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 11 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 38 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 22 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 15 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 1 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 28 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 31 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 65 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 16 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 38 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 63 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 22 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 26 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 265, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 4 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 14 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 13 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 23 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 57 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 65 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 264, options: [
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 5 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 86 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 35 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 37 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 15 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 5 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 43 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 49 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 33 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 264, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 24 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 17 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 23 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 31 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 30 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 59 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 87 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 14 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 11 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 61 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 12 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 15 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 38 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 22 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 264, options: [
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 8 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 60 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 16 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 26 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 63 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 22 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 13 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 71 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 11 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 11 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 45 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 76 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 65 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 23 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 57 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 266, options: [
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 23 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 47 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 10 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 33 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 43 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 49 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 13 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 22 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 27 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 266, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 62 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 92 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 53 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 30 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 23 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 31 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 266, options: [
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 19 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 11 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 9 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 22 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 15 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 38 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 28 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 31 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 1 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 16 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 38 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 65 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 22 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 26 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 63 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 265, options: [
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 14 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 13 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 4 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 57 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 65 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 23 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 264, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 86 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 35 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 5 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 15 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 5 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 37 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 49 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 33 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 43 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 264, options: [
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 24 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 17 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 31 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 30 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 23 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 87 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 14 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 59 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 61 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 12 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 11 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 38 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 22 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 15 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 264, options: [
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 60 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 16 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 8 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 63 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 22 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 26 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 71 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 11 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 13 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 45 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 76 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 11 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 23 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 57 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 65 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 266, options: [
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 47 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 10 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 23 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 43 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 49 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 33 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 22 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 27 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 13 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 266, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 92 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 53 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 62 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 23 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 31 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 30 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 266, options: [
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 11 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 9 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 19 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 15 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 38 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 22 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 31 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 1 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 28 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 38 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 65 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 16 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 26 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 63 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 22 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 265, options: [
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 13 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 4 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 14 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 65 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 23 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 57 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 264, options: [
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 35 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 5 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 86 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 5 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 37 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 15 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 33 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 43 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 49 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 264, options: [
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 17 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 24 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 30 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 23 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 31 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 14 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 59 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 87 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 12 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 11 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 61 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 22 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 15 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 38 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 264, options: [
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 16 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 8 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 60 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 22 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 26 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 63 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 11 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 13 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 71 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 265, options: [
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 76 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 11 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 45 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 265, options: [
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 57 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 65 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 23 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 266, options: [
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 10 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 23 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 47 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 265, options: [
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 49 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 33 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 43 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 265, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 27 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 13 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 22 q çörək" },
    ] },
  ],
];

const GROUP_1400_1499: DayMenu[] = [
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 19 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 73 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 46 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 285, options: [
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 70 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 31 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 30 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 18 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 31 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 25 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 286, options: [
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 57 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 39 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 34 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 35 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 35 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 18 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 23 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 3 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 83 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 285, options: [
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 50 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 46 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 23 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 68 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 2 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 21 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 286, options: [
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 38 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 65 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 31 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 286, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 67 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 5 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 30 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 4 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 44 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 100 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 284, options: [
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 29 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 40 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 72 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 32 q çörək" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 27 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 31 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 285, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 30 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 70 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 31 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 13 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 20 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 79 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 69 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 20 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 12 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 286, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 34 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 57 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 39 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 7 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 9 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 16 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 285, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 23 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 50 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 46 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 9 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 22 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 38 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 18 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 60 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 53 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 286, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 31 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 38 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 65 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 54 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 24 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 17 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 284, options: [
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 72 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 29 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 40 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 20 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 43 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 94 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 73 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 46 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 19 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 285, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 31 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 30 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 70 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 31 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 25 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 18 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 286, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 39 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 34 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 57 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 35 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 18 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 35 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 3 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 83 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 23 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 285, options: [
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 46 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 23 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 50 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 2 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 21 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 68 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 286, options: [
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 65 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 31 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 38 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 286, options: [
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 5 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 30 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 67 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 44 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 100 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 4 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 284, options: [
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 40 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 72 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 29 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 27 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 31 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 32 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 285, options: [
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 70 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 31 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 30 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 20 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 79 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 13 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 20 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 12 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 69 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 286, options: [
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 57 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 39 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 34 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 9 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 16 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 7 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 285, options: [
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 50 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 46 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 23 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 22 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 38 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 9 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 60 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 53 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 18 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 286, options: [
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 38 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 65 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 31 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 24 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 17 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 54 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 284, options: [
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 29 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 40 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 72 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 43 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 94 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 20 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 46 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 19 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 73 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 285, options: [
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 30 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 70 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 31 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 25 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 18 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 31 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 286, options: [
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 34 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 57 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 39 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 18 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 35 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 35 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 83 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 23 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 3 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 285, options: [
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 23 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 50 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 46 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 21 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 68 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 2 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 286, options: [
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 31 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 38 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 65 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 286, options: [
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 30 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 67 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 5 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 100 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 4 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 44 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 284, options: [
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 72 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 29 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 40 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 31 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 32 q çörək" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 27 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 285, options: [
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 31 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 30 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 70 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 79 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 13 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 20 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 12 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 69 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 20 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 286, options: [
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 39 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 34 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 57 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 16 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 7 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 9 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 285, options: [
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 46 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 23 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 50 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 38 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 9 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 22 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 53 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 18 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 60 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 286, options: [
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 65 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 31 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 38 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 17 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 54 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 24 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 284, options: [
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 40 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 72 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 29 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 94 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 20 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 43 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 19 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 73 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 46 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 285, options: [
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 70 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 31 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 30 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 18 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 31 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 25 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 286, options: [
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 57 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 39 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 34 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 35 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 35 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 18 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 23 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 3 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 83 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 285, options: [
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 50 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 46 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 23 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 68 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 2 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 21 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 286, options: [
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 38 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 65 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 31 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 286, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 67 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 5 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 30 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 4 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 44 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 100 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 284, options: [
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 29 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 40 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 72 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 32 q çörək" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 27 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 31 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 285, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 30 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 70 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 31 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 13 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 20 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 79 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 69 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 20 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 12 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 286, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 34 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 57 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 39 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 7 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 9 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 16 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 285, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 23 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 50 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 46 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 9 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 22 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 38 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 18 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 60 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 53 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 286, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 31 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 38 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 65 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 54 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 24 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 17 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 284, options: [
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 72 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 29 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 40 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 20 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 43 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 94 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 285, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 73 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 46 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 19 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 285, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 31 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 30 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 70 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 285, options: [
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 31 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 25 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 18 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 286, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 39 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 34 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 57 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 285, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 35 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 18 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 35 q çörək" },
    ] },
  ],
];

const GROUP_1500_1599: DayMenu[] = [
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 60 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 53 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 77 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 37 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 78 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 30 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 15 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 39 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 29 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 304, options: [
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 72 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 37 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 38 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 304, options: [
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 26 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 29 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 16 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 20 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 27 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 12 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 53 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 58 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 48 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 10 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 25 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 10 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 304, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 46 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 64 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 41 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 305, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 86 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 28 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 20 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 306, options: [
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 91 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 52 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 31 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 38 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 80 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 45 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 38 q çörək" },
      { emoji: "🍲", name: "160 q mərcimək + 80 q kartof + 100 q pomidor + 12 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 19 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 30 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 37 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 78 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 304, options: [
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 37 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 12 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 74 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 68 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 11 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 80 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 304, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 38 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 72 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 37 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 26 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 23 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 150 q kələm + 2 q yağ + 6 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 48 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 53 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 58 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 305, options: [
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 50 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 42 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 102 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 107 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 26 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 27 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 304, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 41 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 46 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 64 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 14 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 34 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 62 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 45 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 38 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 80 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 306, options: [
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 28 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 43 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 46 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 53 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 77 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 60 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 78 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 30 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 37 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 39 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 29 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 15 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 304, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 37 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 38 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 72 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 304, options: [
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 29 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 16 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 26 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 27 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 12 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 20 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 58 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 48 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 53 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 25 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 10 q çörək" },
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 10 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 304, options: [
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 64 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 41 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 46 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 305, options: [
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 28 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 20 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 86 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 306, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 52 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 31 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 91 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 80 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 45 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 38 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "160 q mərcimək + 80 q kartof + 100 q pomidor + 12 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 19 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 38 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 37 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 78 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 30 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 304, options: [
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 12 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 74 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 37 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 11 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 80 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 68 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 304, options: [
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 72 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 37 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 38 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 23 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 150 q kələm + 2 q yağ + 6 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 26 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 53 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 58 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 48 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 305, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 42 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 102 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 50 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 26 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 27 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 107 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 304, options: [
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 46 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 64 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 41 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 34 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 62 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 14 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 38 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 80 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 45 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 306, options: [
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 43 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 46 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 28 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 77 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 60 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 53 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 30 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 37 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 78 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 29 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 15 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 39 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 304, options: [
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 38 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 72 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 37 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 304, options: [
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 16 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 26 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 29 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 12 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 20 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 27 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 48 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 53 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 58 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 10 q çörək" },
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 10 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 25 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 304, options: [
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 41 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 46 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 64 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 305, options: [
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 20 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 86 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 28 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 306, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 31 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 91 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 52 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 45 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 38 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 80 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 19 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 38 q çörək" },
      { emoji: "🍲", name: "160 q mərcimək + 80 q kartof + 100 q pomidor + 12 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 78 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 30 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 37 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 304, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 74 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 37 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 12 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 80 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 68 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 11 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 304, options: [
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 37 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 38 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 72 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 150 q kələm + 2 q yağ + 6 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 26 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 23 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 58 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 48 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 53 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 305, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 102 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 50 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 42 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 27 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 107 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 26 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 304, options: [
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 64 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 41 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 46 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 62 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 14 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 34 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 80 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 45 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 38 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 306, options: [
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 46 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 28 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 43 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 60 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 53 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 77 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 37 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 78 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 30 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 15 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 39 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 29 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 304, options: [
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 72 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 37 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 38 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 304, options: [
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 26 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 29 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 16 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 20 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 27 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 12 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 53 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 58 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 48 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 10 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 25 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 10 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 304, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 46 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 64 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 41 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 305, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 86 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 28 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 20 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 306, options: [
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 91 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 52 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 31 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 38 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 80 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 45 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 38 q çörək" },
      { emoji: "🍲", name: "160 q mərcimək + 80 q kartof + 100 q pomidor + 12 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 19 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 30 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 37 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 78 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 304, options: [
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 37 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 12 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 74 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 68 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 11 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 80 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 304, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 38 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 72 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 37 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 26 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 23 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 150 q kələm + 2 q yağ + 6 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 48 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 53 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 58 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 305, options: [
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 50 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 42 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 102 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 107 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 26 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 27 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 304, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 41 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 46 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 64 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 14 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 34 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 62 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 305, options: [
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 45 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 38 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 80 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 306, options: [
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 28 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 43 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 46 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 305, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 53 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 77 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 60 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 305, options: [
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 78 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 30 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 37 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 305, options: [
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 39 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 29 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 15 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 304, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 37 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 38 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 72 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 304, options: [
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 29 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 16 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 26 q çörək" },
    ] },
  ],
];

const GROUP_1600_1699: DayMenu[] = [
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 88 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 61 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 59 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 325, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 49 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 65 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 55 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 46 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 23 q çörək" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 42 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 45 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 80 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 61 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 324, options: [
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 28 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 50 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 35 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 324, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 34 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 84 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 75 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 46 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 72 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 38 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 324, options: [
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 31 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 33 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 83 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 324, options: [
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 44 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 87 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 85 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 326, options: [
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 24 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 37 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 94 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 324, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 38 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 33 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 98 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 46 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 53 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 54 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 46 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 40 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 24 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 325, options: [
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 55 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 49 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 65 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 326, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 109 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 58 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 54 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 35 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 18 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 68 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 61 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 45 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 80 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 32 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 39 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 47 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 38 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 46 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 72 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 324, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 50 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 35 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 33 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 19 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 115 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 27 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 324, options: [
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 85 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 44 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 87 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 326, options: [
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 18 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 36 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 22 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 54 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 46 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 53 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 325, options: [
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 20 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 45 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 82 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 61 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 59 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 88 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 325, options: [
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 65 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 55 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 49 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 23 q çörək" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 42 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 46 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 80 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 61 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 45 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 324, options: [
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 50 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 35 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 28 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 324, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 84 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 75 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 34 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 72 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 38 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 46 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 324, options: [
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 33 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 83 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 31 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 324, options: [
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 87 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 85 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 44 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 326, options: [
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 37 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 94 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 24 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 324, options: [
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 33 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 98 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 38 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 53 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 54 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 46 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 40 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 24 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 46 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 325, options: [
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 49 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 65 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 55 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 326, options: [
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 58 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 54 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 109 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 18 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 68 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 35 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 45 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 80 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 61 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 39 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 47 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 32 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 46 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 72 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 38 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 324, options: [
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 35 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 33 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 50 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 115 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 27 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 19 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 324, options: [
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 44 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 87 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 85 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 326, options: [
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 36 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 22 q çörək" },
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 18 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 46 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 53 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 54 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 325, options: [
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 45 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 82 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 20 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 59 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 88 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 61 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 325, options: [
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 55 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 49 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 65 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 42 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 46 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 23 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 61 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 45 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 80 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 324, options: [
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 35 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 28 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 50 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 324, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 75 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 34 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 84 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 38 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 46 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 72 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 324, options: [
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 83 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 31 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 33 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 324, options: [
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 85 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 44 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 87 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 326, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 94 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 24 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 37 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 324, options: [
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 98 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 38 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 33 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 54 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 46 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 53 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 24 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 46 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 40 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 325, options: [
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 65 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 55 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 49 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 326, options: [
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 54 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 109 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 58 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 68 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 35 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 18 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 80 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 61 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 45 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 47 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 32 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 39 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 72 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 38 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 46 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 324, options: [
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 33 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 50 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 35 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 27 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 19 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 115 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 324, options: [
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 87 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 85 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 44 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 326, options: [
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 22 q çörək" },
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 18 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 36 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 53 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 54 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 46 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 325, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 82 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 20 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 45 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 88 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 61 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 59 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 325, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 49 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 65 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 55 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 46 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 23 q çörək" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 42 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 45 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 80 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 61 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 324, options: [
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 28 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 50 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 35 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 324, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 34 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 84 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 75 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 46 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 72 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 38 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 324, options: [
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 31 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 33 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 83 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 324, options: [
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 44 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 87 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 85 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 326, options: [
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 24 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 37 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 94 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 324, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 38 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 33 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 98 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 46 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 53 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 54 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 46 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 40 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 24 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 325, options: [
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 55 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 49 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 65 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 326, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 109 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 58 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 54 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 35 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 18 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 68 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 326, options: [
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 61 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 45 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 80 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 32 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 39 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 47 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 38 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 46 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 72 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 324, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 50 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 35 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 33 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 19 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 115 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 27 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 324, options: [
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 85 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 44 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 87 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 326, options: [
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 18 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 36 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 22 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 54 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 46 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 53 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 325, options: [
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 20 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 45 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 82 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 325, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 61 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 59 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 88 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 325, options: [
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 65 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 55 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 49 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 325, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 23 q çörək" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 42 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 46 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 326, options: [
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 80 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 61 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 45 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 324, options: [
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 50 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 35 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 28 q çörək" },
    ] },
  ],
];

const GROUP_1700_1799: DayMenu[] = [
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 35 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 26 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 122 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 345, options: [
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 60 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 53 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 62 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 40 q çörək" },
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 25 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 44 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 346, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 46 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 93 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 95 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 345, options: [
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 43 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 58 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 57 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 106 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 41 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 68 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 52 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 53 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 63 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 344, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 34 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 53 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 49 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 87 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 73 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 68 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 61 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 65 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 31 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 346, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 83 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 92 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 42 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 79 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 56 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 52 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 39 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 150 q kələm + 2 q yağ + 21 q çörək" },
      { emoji: "🍲", name: "160 q mərcimək + 80 q kartof + 100 q pomidor + 27 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 345, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 62 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 60 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 53 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 43 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 44 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 35 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 75 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 27 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 42 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 346, options: [
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 95 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 46 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 93 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 54 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 77 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 38 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 63 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 52 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 53 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 345, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 101 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 117 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 89 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 346, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 67 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 46 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 96 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 68 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 87 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 73 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 30 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 25 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 41 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 52 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 79 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 56 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 52 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 27 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 41 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 26 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 122 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 35 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 345, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 53 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 62 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 60 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 25 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 44 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 40 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 346, options: [
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 93 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 95 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 46 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 345, options: [
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 58 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 57 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 43 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 41 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 68 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 106 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 53 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 63 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 52 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 344, options: [
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 53 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 49 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 34 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 73 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 68 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 87 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 65 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 31 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 61 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 346, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 92 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 42 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 83 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 56 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 52 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 79 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 150 q kələm + 2 q yağ + 21 q çörək" },
      { emoji: "🍲", name: "160 q mərcimək + 80 q kartof + 100 q pomidor + 27 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 39 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 345, options: [
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 60 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 53 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 62 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 44 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 35 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 43 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 27 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 42 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 75 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 346, options: [
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 46 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 93 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 95 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 77 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 38 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 54 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 52 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 53 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 63 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 345, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 117 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 89 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 101 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 346, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 46 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 96 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 67 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 87 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 73 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 68 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 25 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 41 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 30 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 79 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 56 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 52 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 27 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 41 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 52 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 122 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 35 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 26 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 345, options: [
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 62 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 60 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 53 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 44 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 40 q çörək" },
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 25 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 346, options: [
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 95 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 46 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 93 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 345, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 57 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 43 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 58 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 68 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 106 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 41 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 63 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 52 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 53 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 344, options: [
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 49 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 34 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 53 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 68 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 87 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 73 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 31 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 61 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 65 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 346, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 42 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 83 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 92 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 52 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 79 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 56 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "160 q mərcimək + 80 q kartof + 100 q pomidor + 27 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 39 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 150 q kələm + 2 q yağ + 21 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 345, options: [
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 53 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 62 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 60 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 35 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 43 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 44 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 42 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 75 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 27 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 346, options: [
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 93 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 95 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 46 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 38 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 54 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 77 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 53 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 63 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 52 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 345, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 89 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 101 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 117 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 346, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 96 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 67 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 46 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 73 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 68 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 87 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 41 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 30 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 25 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 56 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 52 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 79 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 41 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 52 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 27 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 35 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 26 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 122 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 345, options: [
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 60 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 53 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 62 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 40 q çörək" },
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 25 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 44 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 346, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 46 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 93 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 95 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 345, options: [
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 43 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 58 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 57 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 106 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 41 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 68 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 52 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 53 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 63 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 344, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 34 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 53 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 70 q düyü + 100 q kələm + 49 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 87 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 73 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 68 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 61 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 65 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 31 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 346, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 83 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 92 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 42 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 79 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 56 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 52 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 39 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 150 q kələm + 2 q yağ + 21 q çörək" },
      { emoji: "🍲", name: "160 q mərcimək + 80 q kartof + 100 q pomidor + 27 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 345, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 62 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 60 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 53 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 43 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 44 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 35 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 75 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 27 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 42 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 346, options: [
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 95 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 46 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 93 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 54 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 150 q pomidor + 100 q xiyar + 77 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 38 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 63 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 52 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 53 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 345, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 101 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 117 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 89 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 346, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 67 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 46 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 96 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 344, options: [
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 68 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 87 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 73 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 30 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 80 q düyü + 100 q kələm + 2 q yağ + 25 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 120 q kartof + 100 q pomidor + 41 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 344, options: [
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 52 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 79 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 56 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 344, options: [
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 52 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 27 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 41 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 345, options: [
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 26 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 122 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 35 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 345, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 53 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 62 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 60 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 345, options: [
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 25 q çörək" },
      { emoji: "🍲", name: "120 q lobya + 70 q kartof + 100 q xiyar + 44 q çörək" },
      { emoji: "🍲", name: "70 q toyuq + 70 q düyü + 100 q pomidor + 100 q xiyar + 40 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 346, options: [
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 93 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 95 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 46 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 345, options: [
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 58 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 57 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 43 q çörək" },
    ] },
  ],
];

const GROUP_1800_1899: DayMenu[] = [
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 103 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 53 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 33 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 53 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 68 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 59 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 366, options: [
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 33 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 46 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 37 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 80 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 64 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 87 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 65 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 73 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 69 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 50 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 34 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 74 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 61 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 60 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 95 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 38 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 46 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 55 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 71 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 61 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 102 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 364, options: [
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 43 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 124 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 50 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 365, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 76 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 99 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 43 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 76 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 100 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 69 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 39 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 51 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 54 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 59 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 53 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 68 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 366, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 97 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 60 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 49 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 130 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 48 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 90 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 87 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 80 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 64 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 42 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 98 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 61 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 95 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 61 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 60 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 35 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 109 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 50 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 365, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 49 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 83 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 113 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 102 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 71 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 61 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 61 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 62 q çörək" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 57 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 69 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 76 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 100 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 52 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 65 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 39 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 53 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 33 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 103 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 68 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 59 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 53 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 366, options: [
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 46 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 37 q çörək" },
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 33 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 64 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 87 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 80 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 73 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 69 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 65 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 34 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 74 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 50 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 60 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 95 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 61 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 46 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 55 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 38 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 61 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 102 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 71 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 364, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 124 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 50 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 43 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 365, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 99 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 43 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 76 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 100 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 69 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 76 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 51 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 54 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 39 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 53 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 68 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 59 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 366, options: [
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 60 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 49 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 97 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 48 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 90 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 130 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 80 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 64 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 87 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 98 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 61 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 42 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 61 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 60 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 95 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 109 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 50 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 35 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 365, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 83 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 113 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 49 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 71 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 61 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 102 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 62 q çörək" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 57 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 61 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 76 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 100 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 69 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 65 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 39 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 52 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 33 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 103 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 53 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 59 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 53 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 68 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 366, options: [
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 37 q çörək" },
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 33 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 46 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 87 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 80 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 64 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 69 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 65 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 73 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 74 q çörək" },
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 50 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 34 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 95 q çörək" },
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 61 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 60 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 55 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 38 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 46 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 102 q çörək" },
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 71 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 61 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 364, options: [
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 50 q çörək" },
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 43 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 124 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 365, options: [
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 43 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 76 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 99 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 69 q çörək" },
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 76 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 100 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 54 q çörək" },
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 39 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 51 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 68 q çörək" },
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 59 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 53 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 366, options: [
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 49 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 97 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 60 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 90 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 130 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 48 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 64 q çörək" },
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 87 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 80 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 61 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 42 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 98 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 60 q çörək" },
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 95 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 61 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 50 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 35 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 109 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 365, options: [
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 113 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 49 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 83 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 61 q çörək" },
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 102 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 71 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 57 q çörək" },
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 61 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 62 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 100 q çörək" },
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 69 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 76 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 39 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 52 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 65 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 103 q çörək" },
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 53 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 33 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 53 q çörək" },
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 68 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 59 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 366, options: [
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 33 q çörək" },
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 46 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 37 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 80 q çörək" },
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 64 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 87 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 65 q çörək" },
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 73 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 69 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "200 q süd + 150 q alma + 5 q qoz + 50 q çörək" },
      { emoji: "🍳", name: "250 q süd + 100 q banan + 5 q qoz + 34 q çörək" },
      { emoji: "🍳", name: "150 q kəsmik + 100 q pomidor + 74 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "250 q kefir + 80 q banan + 61 q çörək" },
      { emoji: "🍏", name: "200 q süd + 100 q alma + 5 q qoz + 60 q çörək" },
      { emoji: "🍏", name: "80 q banan + 15 q pendir + 95 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 50 q kök + 20 q soğan + 38 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 100 q kartof + 100 q kələm + 46 q çörək" },
      { emoji: "🍲", name: "60 q toyuq + 100 q kartof + 100 q pomidor + 100 q xiyar + 55 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "150 q alma + 100 q kəsmik + 71 q çörək" },
      { emoji: "🥛", name: "150 q alma + 150 q qatıq + 5 q qoz + 61 q çörək" },
      { emoji: "🥛", name: "100 q alma + 15 q pendir + 102 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 364, options: [
      { emoji: "🌙", name: "80 q toyuq + 80 q düyü + 100 q xiyar + 43 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q pomidor + 100 q xiyar + 124 q çörək" },
      { emoji: "🌙", name: "70 q toyuq + 70 q düyü + 100 q kələm + 50 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 365, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 100 q pomidor + 76 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 30 q pendir + 100 q xiyar + 99 q çörək" },
      { emoji: "🍳", name: "200 q qatıq + 150 q alma + 8 q fındıq + 43 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "200 q süd + 15 q pendir + 76 q çörək" },
      { emoji: "🍏", name: "100 q armud + 15 q pendir + 100 q çörək" },
      { emoji: "🍏", name: "100 q banan + 150 q qatıq + 69 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "90 q balıq + 80 q düyü + 100 q kələm + 2 q yağ + 39 q çörək" },
      { emoji: "🍲", name: "130 q mərcimək + 70 q kartof + 100 q pomidor + 51 q çörək" },
      { emoji: "🍲", name: "80 q balıq + 100 q kartof + 100 q pomidor + 100 q xiyar + 54 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "200 q qatıq + 100 q alma + 5 q fındıq + 59 q çörək" },
      { emoji: "🥛", name: "150 q armud + 200 q kefir + 5 q qoz + 53 q çörək" },
      { emoji: "🥛", name: "150 q armud + 100 q kəsmik + 68 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 366, options: [
      { emoji: "🌙", name: "2 ədəd yumurta + 100 q kartof + 100 q pomidor + 97 q çörək" },
      { emoji: "🌙", name: "80 q balıq + 100 q kartof + 100 q pomidor + 60 q çörək" },
      { emoji: "🌙", name: "90 q balıq + 80 q düyü + 100 q pomidor + 49 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "2 ədəd yumurta + 100 q pomidor + 130 q çörək" },
      { emoji: "🍳", name: "180 q kəsmik + 100 q armud + 48 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 120 q kartof + 100 q pomidor + 90 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "150 q qatıq + 15 q pendir + 87 q çörək" },
      { emoji: "🍏", name: "100 q kəsmik + 100 q alma + 80 q çörək" },
      { emoji: "🍏", name: "200 q kefir + 100 q armud + 5 q qoz + 64 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "80 q toyuq + 120 q kartof + 100 q pomidor + 42 q çörək" },
      { emoji: "🍲", name: "2 ədəd yumurta + 80 q kartof + 100 q pomidor + 100 q xiyar + 98 q çörək" },
      { emoji: "🍲", name: "140 q lobya + 100 q pomidor + 20 q soğan + 61 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "80 q banan + 15 q pendir + 95 q çörək" },
      { emoji: "🥛", name: "250 q kefir + 80 q banan + 61 q çörək" },
      { emoji: "🥛", name: "200 q süd + 100 q alma + 5 q qoz + 60 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "140 q lobya + 80 q kartof + 100 q kələm + 35 q çörək" },
      { emoji: "🌙", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 109 q çörək" },
      { emoji: "🌙", name: "55 q mal əti + 100 q kartof + 100 q kələm + 50 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 365, options: [
      { emoji: "🍳", name: "150 q kəsmik + 100 q alma + 5 q qoz + 49 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q kartof + 83 q çörək" },
      { emoji: "🍳", name: "3 ədəd yumurta + 15 q pendir + 100 q pomidor + 113 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "100 q alma + 15 q pendir + 102 q çörək" },
      { emoji: "🍏", name: "150 q alma + 100 q kəsmik + 71 q çörək" },
      { emoji: "🍏", name: "150 q alma + 150 q qatıq + 5 q qoz + 61 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 365, options: [
      { emoji: "🍲", name: "150 q mərcimək + 20 q soğan + 50 q kök + 61 q çörək" },
      { emoji: "🍲", name: "70 q balıq + 100 q kartof + 100 q kələm + 62 q çörək" },
      { emoji: "🍲", name: "50 q mal əti + 100 q kartof + 100 q pomidor + 57 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "100 q banan + 150 q qatıq + 69 q çörək" },
      { emoji: "🥛", name: "200 q süd + 15 q pendir + 76 q çörək" },
      { emoji: "🥛", name: "100 q armud + 15 q pendir + 100 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "70 q toyuq + 100 q kartof + 100 q kələm + 52 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 100 q pomidor + 65 q çörək" },
      { emoji: "🌙", name: "150 q mərcimək + 80 q kartof + 100 q pomidor + 39 q çörək" },
    ] },
  ],
  [
    { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra", kcal: 364, options: [
      { emoji: "🍳", name: "120 q kəsmik + 80 q banan + 5 q qoz + 53 q çörək" },
      { emoji: "🍳", name: "250 q qatıq + 100 q banan + 5 q qoz + 33 q çörək" },
      { emoji: "🍳", name: "2 ədəd yumurta + 20 q pendir + 100 q pomidor + 100 q xiyar + 103 q çörək" },
    ] },
    { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları", kcal: 365, options: [
      { emoji: "🍏", name: "150 q armud + 100 q kəsmik + 68 q çörək" },
      { emoji: "🍏", name: "200 q qatıq + 100 q alma + 5 q fındıq + 59 q çörək" },
      { emoji: "🍏", name: "150 q armud + 200 q kefir + 5 q qoz + 53 q çörək" },
    ] },
    { key: "noon", title: "Günorta dəstəyi", time: "günün ortası", kcal: 366, options: [
      { emoji: "🍲", name: "80 q toyuq + 100 q kartof + 100 q kələm + 46 q çörək" },
      { emoji: "🍲", name: "60 q mal əti + 80 q düyü + 100 q pomidor + 100 q xiyar + 37 q çörək" },
      { emoji: "🍲", name: "150 q lobya + 80 q kartof + 100 q pomidor + 33 q çörək" },
    ] },
    { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı", kcal: 365, options: [
      { emoji: "🥛", name: "200 q kefir + 100 q armud + 5 q qoz + 64 q çörək" },
      { emoji: "🥛", name: "150 q qatıq + 15 q pendir + 87 q çörək" },
      { emoji: "🥛", name: "100 q kəsmik + 100 q alma + 80 q çörək" },
    ] },
    { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı", kcal: 365, options: [
      { emoji: "🌙", name: "120 q kəsmik + 100 q alma + 73 q çörək" },
      { emoji: "🌙", name: "150 q kəsmik + 100 q pomidor + 100 q xiyar + 69 q çörək" },
      { emoji: "🌙", name: "140 q lobya + 100 q xiyar + 65 q çörək" },
    ] },
  ],
];

export const GROUP_MENUS: Record<CalorieGroupKey, DayMenu[]> = {
  "1200_1299": GROUP_1200_1299,
  "1300_1399": GROUP_1300_1399,
  "1400_1499": GROUP_1400_1499,
  "1500_1599": GROUP_1500_1599,
  "1600_1699": GROUP_1600_1699,
  "1700_1799": GROUP_1700_1799,
  "1800_1899": GROUP_1800_1899,
};
