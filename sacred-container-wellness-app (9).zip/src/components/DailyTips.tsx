import { motion, type Variants } from "framer-motion";

const TIPS = [
  { emoji: "💧", title: "Su", text: "Gün ərzində 2.5–3 litr təmiz su iç" },
  { emoji: "🚶", title: "Gəzinti", text: "30–40 dəqiqə yumşaq gəzinti" },
  { emoji: "🧂", title: "Duz", text: "Gündə 3–5 q duz (çox deyil, az yox)" },
  { emoji: "🌙", title: "Yuxu", text: "7–8 saat keyfiyyətli dincəlmə" },
];

const tipContainer: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.05 } },
};
const tipItem: Variants = {
  hidden: { opacity: 0, y: 14, scale: 0.96 },
  show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] } },
};

export default function DailyTips({ delay = 0 }: { delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5, ease: [0.25, 1, 0.5, 1] }}
      className="glass-soft rounded-[22px] p-4"
      style={{ boxShadow: "inset 0 0 0 1px rgba(251,206,177,0.14)" }}
    >
      <p className="eyebrow mb-3">21 günlük proqramın vacib addımları</p>
      <motion.div
        variants={tipContainer}
        initial="hidden"
        animate="show"
        className="grid grid-cols-2 gap-2.5"
      >
        {TIPS.map((tip) => (
          <motion.div
            key={tip.title}
            variants={tipItem}
            whileHover={{ y: -3, scale: 1.02 }}
            transition={{ type: "spring", stiffness: 360, damping: 22 }}
            className="flex items-center gap-2.5 rounded-[16px] p-2.5"
            style={{ background: "rgba(255,255,255,0.025)" }}
          >
            <motion.span
              whileHover={{ rotate: [0, -8, 8, 0] }}
              transition={{ duration: 0.5 }}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-[17px]"
              style={{
                background: "linear-gradient(135deg, rgba(251,206,177,0.22), rgba(245,184,149,0.06))",
              }}
            >
              {tip.emoji}
            </motion.span>
            <div>
              <p className="text-[13px] font-bold text-[var(--ink)]">{tip.title}</p>
              <p className="text-[12px] leading-tight text-[var(--ink-dim)]">{tip.text}</p>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
}
