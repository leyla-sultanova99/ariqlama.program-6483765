import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { StoreProvider, useStore } from "@/lib/store";
import { ToastProvider } from "@/components/ui/Toast";
import Background from "@/components/ui/Background";
import CustomCursor from "@/components/ui/CustomCursor";
import Confetti from "@/components/ui/Confetti";
import Onboarding from "@/components/Onboarding";
import MenuScreen from "@/screens/MenuScreen";

/* =====================================================================
   İNCİ — 30 GÜNLÜK PROQRAM
   - 21 gün (gün 1-21), hər gün unikal menyu
   - Heç bir pro/ödəniş/paywall ekranı YOXDUR
===================================================================== */

function Splash() {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.04, filter: "blur(8px)" }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      className="fixed inset-0 z-[70] flex flex-col items-center justify-center"
    >
      <div className="relative flex h-32 w-32 items-center justify-center">
        {[0, 1, 2, 3].map((i) => (
          <motion.span key={i} className="absolute rounded-full"
            style={{ width: 86, height: 86, border: "1px solid rgba(251,206,177,0.5)" }}
            animate={{ scale: [0.8, 1.6], opacity: [0.6, 0] }}
            transition={{ duration: 2.6, repeat: Infinity, ease: [0.22, 1, 0.36, 1], delay: i * 0.65 }}
          />
        ))}
        <motion.div
          className="pointer-events-none absolute rounded-full"
          style={{ width: 110, height: 110, background: "radial-gradient(circle, rgba(251,206,177,0.35), transparent 70%)" }}
          animate={{ scale: [0.9, 1.15, 0.9], opacity: [0.4, 0.75, 0.4] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div className="avatar-orb flex h-[86px] w-[86px] items-center justify-center rounded-full"
          initial={{ scale: 0.6, opacity: 0, rotate: -8 }}
          animate={{ scale: [1, 1.05, 1], opacity: 1, rotate: 0 }}
          transition={{
            scale: { duration: 2.4, repeat: Infinity, ease: "easeInOut" },
            opacity: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
            rotate: { duration: 0.7, ease: [0.2, 1.65, 0.4, 1] },
          }}
        >
          <motion.span
            style={{ fontSize: 38 }}
            animate={{ rotate: [0, 4, -4, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          >
            🪷
          </motion.span>
        </motion.div>
      </div>
      <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="t-hero text-shimmer mt-7">İnci</motion.p>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="t-small mt-1 text-[var(--ink-dim)]">Sənin rəqəmsal sığınacağın</motion.p>
      <div className="skeleton mt-8 h-1.5 w-32" />
    </motion.div>
  );
}

function Shell() {
  const { onboarded } = useStore();
  const [booted, setBooted] = useState(() => onboarded);
  const [confettiTrigger, setConfettiTrigger] = useState(0);

  useEffect(() => {
    if (onboarded) return;
    const t = window.setTimeout(() => setBooted(true), 1700);
    return () => window.clearTimeout(t);
  }, [onboarded]);

  useEffect(() => {
    function onCelebrate() { setConfettiTrigger((n) => n + 1); }
    window.addEventListener("celebrate", onCelebrate);
    return () => window.removeEventListener("celebrate", onCelebrate);
  }, []);

  return (
    <>
      <Background />
      <CustomCursor />
      <Confetti trigger={confettiTrigger} />

      <AnimatePresence>
        {!booted && <Splash key="splash" />}
        {booted && !onboarded && <Onboarding key="onboarding" />}
      </AnimatePresence>

      {booted && onboarded && (
        <main className="relative z-10 mx-auto min-h-dvh w-full max-w-[460px] px-5 pb-16 pt-14">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key="menu"
              initial={{ opacity: 0, y: 26, scale: 0.985, filter: "blur(4px)" }}
              animate={{ opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -14, scale: 0.99, filter: "blur(3px)" }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            >
              <MenuScreen />
            </motion.div>
          </AnimatePresence>
        </main>
      )}
    </>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <ToastProvider>
        <Shell />
      </ToastProvider>
    </StoreProvider>
  );
}
