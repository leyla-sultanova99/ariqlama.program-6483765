import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  motion,
  useMotionValue,
  useScroll,
  useSpring,
  useTransform,
  type Variants,
} from "framer-motion";
import { cn } from "@/utils/cn";
import { EASE_OUT, useHaptics } from "@/lib/hooks";

/* Richer easing curves for the new premium entrances/exits below. */
const EASE_SILK = [0.22, 1, 0.36, 1] as const;
const EASE_ELASTIC = [0.2, 1.65, 0.4, 1] as const;

/* ---------- Reveal: scroll-triggered entrance ---------- */
export function Reveal({
  children,
  delay = 0,
  y = 18,
  className,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.6, delay, ease: EASE_OUT }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/* ---------- Stagger: list reveals one-by-one ---------- */
const container: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.05 } },
};
const item: Variants = {
  hidden: { opacity: 0, y: 16, scale: 0.98 },
  show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.55, ease: EASE_OUT } },
};

export function Stagger({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <motion.div
      variants={container}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-40px" }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function StaggerItem({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <motion.div variants={item} className={className}>
      {children}
    </motion.div>
  );
}

/* ---------- Magnetic: subtle cursor attraction (desktop) ---------- */
export function Magnetic({
  children,
  strength = 0.35,
  className,
}: {
  children: ReactNode;
  strength?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 250, damping: 18, mass: 0.4 });
  const sy = useSpring(y, { stiffness: 250, damping: 18, mass: 0.4 });
  const { vibrate } = useHaptics();

  function onMove(e: React.MouseEvent<HTMLDivElement>) {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const mx = e.clientX - (r.left + r.width / 2);
    const my = e.clientY - (r.top + r.height / 2);
    x.set(mx * strength);
    y.set(my * strength);
  }
  function reset() {
    x.set(0);
    y.set(0);
  }

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      onMouseEnter={() => vibrate(6)}
      onMouseLeave={reset}
      style={{ x: sx, y: sy }}
      className={cn("inline-block", className)}
    >
      {children}
    </motion.div>
  );
}

/* ---------- TiltCard: 3D perspective tilt on hover ---------- */
export function Tilt({
  children,
  className,
  intensity = 8,
}: {
  children: ReactNode;
  className?: string;
  intensity?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const srx = useSpring(rx, { stiffness: 200, damping: 18 });
  const sry = useSpring(ry, { stiffness: 200, damping: 18 });

  function onMove(e: React.MouseEvent<HTMLDivElement>) {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    ry.set(px * intensity);
    rx.set(-py * intensity);
  }
  function reset() {
    rx.set(0);
    ry.set(0);
  }

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={reset}
      style={{ rotateX: srx, rotateY: sry, transformStyle: "preserve-3d" }}
      className={cn("perspective", className)}
    >
      {children}
    </motion.div>
  );
}

/* ---------- FadeBlur: premium blur+scale+y entrance (richer than Reveal) ---------- */
export function FadeBlur({
  children,
  delay = 0,
  y = 14,
  duration = 0.6,
  className,
  once = true,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  duration?: number;
  className?: string;
  once?: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y, filter: "blur(6px)", scale: 0.97 }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)", scale: 1 }}
      viewport={{ once, margin: "-40px" }}
      transition={{ duration, delay, ease: EASE_SILK }}
      style={{ willChange: "transform, opacity, filter" }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/* ---------- PopIn: tween-based elastic pop (lighter weight than a spring) ---------- */
export function PopIn({
  children,
  delay = 0,
  duration = 0.5,
  className,
}: {
  children: ReactNode;
  delay?: number;
  duration?: number;
  className?: string;
}) {
  return (
    <motion.div
      initial={{ scale: 0.4, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration, delay, ease: EASE_ELASTIC }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/* ---------- SpringPop: elastic scale-in, great for icons, badges, checkmarks ---------- */
export function SpringPop({
  children,
  delay = 0,
  className,
  stiffness = 340,
  damping = 16,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  stiffness?: number;
  damping?: number;
}) {
  return (
    <motion.div
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: "spring", stiffness, damping, delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/* ---------- TextReveal: per-character rise-in for headlines ---------- */
export function TextReveal({
  text,
  delay = 0,
  stagger = 0.02,
  className,
  as: As = "span",
}: {
  text: string;
  delay?: number;
  stagger?: number;
  className?: string;
  as?: "span" | "h1" | "h2" | "p";
}) {
  const chars = Array.from(text);
  const wrapVariants: Variants = {
    hidden: {},
    show: { transition: { staggerChildren: stagger, delayChildren: delay } },
  };
  const charVariants: Variants = {
    hidden: { opacity: 0, y: "60%", rotateX: -40 },
    show: {
      opacity: 1,
      y: "0%",
      rotateX: 0,
      transition: { duration: 0.5, ease: EASE_SILK },
    },
  };
  return (
    <motion.span
      variants={wrapVariants}
      initial="hidden"
      animate="show"
      className={cn("inline-block", className)}
      style={{ perspective: 400 }}
    >
      <As className="sr-only">{text}</As>
      <span aria-hidden="true">
        {chars.map((ch, i) => (
          <motion.span
            key={i}
            variants={charVariants}
            style={{ display: "inline-block", transformOrigin: "50% 100%" }}
          >
            {ch === " " ? "\u00A0" : ch}
          </motion.span>
        ))}
      </span>
    </motion.span>
  );
}

/* ---------- CountUp: smoothly animated number, settles with a spring ---------- */
export function CountUp({
  value,
  duration = 0.9,
  className,
  formatter,
}: {
  value: number;
  duration?: number;
  className?: string;
  formatter?: (n: number) => string;
}) {
  const [display, setDisplay] = useState(0);
  const raf = useRef<number | null>(null);

  useEffect(() => {
    const start = performance.now();
    const from = display;
    const to = value;
    function tick(now: number) {
      const t = Math.min(1, (now - start) / (duration * 1000));
      const eased = 1 - Math.pow(1 - t, 3); // easeOutCubic
      setDisplay(from + (to - from) * eased);
      if (t < 1) raf.current = requestAnimationFrame(tick);
    }
    raf.current = requestAnimationFrame(tick);
    return () => {
      if (raf.current) cancelAnimationFrame(raf.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, duration]);

  const shown = formatter ? formatter(display) : Math.round(display).toString();

  return (
    <span className={cn("anim-number-settle", className)}>
      {shown}
    </span>
  );
}

/* ---------- ScrollParallax: generic scroll-linked drift for any element ---------- */
export function ScrollParallax({
  children,
  range = 100,
  className,
}: {
  children: ReactNode;
  range?: number;
  className?: string;
}) {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 800], [0, range]);
  const sy = useSpring(y, { stiffness: 50, damping: 22, mass: 0.8 });
  return (
    <motion.div style={{ y: sy }} className={className}>
      {children}
    </motion.div>
  );
}

/* ---------- GlowPulse: wraps children with a soft breathing glow ring behind them ---------- */
export function GlowPulse({
  children,
  className,
  color = "rgba(251,206,177,0.4)",
}: {
  children: ReactNode;
  className?: string;
  color?: string;
}) {
  return (
    <span className={cn("relative inline-flex items-center justify-center", className)}>
      <span
        className="anim-glow-ring-soft pointer-events-none absolute inset-0 rounded-full"
        style={{ boxShadow: `0 0 0 0 ${color}` }}
        aria-hidden
      />
      {children}
    </span>
  );
}
