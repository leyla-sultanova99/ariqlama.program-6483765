import type {
  Profile,
  AgeRange,
  HeightRange,
  WeightRange,
  Gender,
} from "@/lib/store";

const API_KEY =
  "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";

export const CALORIE_GROUPS = [
  { key: "1200_1299", min: 1200, max: 1299 },
  { key: "1300_1399", min: 1300, max: 1399 },
  { key: "1400_1499", min: 1400, max: 1499 },
  { key: "1500_1599", min: 1500, max: 1599 },
  { key: "1600_1699", min: 1600, max: 1699 },
  { key: "1700_1799", min: 1700, max: 1799 },
  { key: "1800_1899", min: 1800, max: 1899 },
] as const;

export interface CalorieGroup {
  key: string;
  min: number;
  max: number;
}

export interface CalorieResult {
  bmr: number;
  tdee: number;
  target: number;
  calorieGroup: CalorieGroup | null;
  effectiveActivity: string;
  effectiveFactor: number;
  source: "gpt" | "local";
}

export type ActivityLevel = "sedentary" | "light" | "moderate" | "active";
export type Level = "A" | "B" | "C" | "D" | "E";

// Anket aralıqları → orta dəyər
const AGE_MID: Record<AgeRange, number> = {
  "18-25": 21, "26-35": 30, "36-45": 40, "46-55": 50, "56+": 62,
};
const HEIGHT_MID: Record<HeightRange, number> = {
  "140-160": 150, "160-175": 167, "175-190": 182, "190+": 195,
};
const WEIGHT_MID: Record<WeightRange, number> = {
  "40-60": 50, "60-80": 70, "80-100": 90, "100-120": 110, "120+": 135,
};
const ACTIVITY_FACTORS: Record<string, number> = {
  sedentary: 1.20, light: 1.375, moderate: 1.55, active: 1.725,
};

export function findCalorieGroup(target: number): CalorieGroup | null {
  for (const g of CALORIE_GROUPS) {
    if (target >= g.min && target <= g.max) return g;
  }
  if (target < 1200) return CALORIE_GROUPS[0];
  if (target > 1899) return CALORIE_GROUPS[6];
  return null;
}

// ── Lokal Mifflin-St Jeor ehtiyat hesabı ──
function localCalc(profile: Profile): CalorieResult {
  const w = WEIGHT_MID[profile.weight] ?? 70;
  const h = HEIGHT_MID[profile.height] ?? 167;
  const a = AGE_MID[profile.age] ?? 30;
  const base = 10 * w + 6.25 * h - 5 * a;
  const bmr = Math.round(profile.gender === "woman" ? base - 161 : base + 5);

  let factor = ACTIVITY_FACTORS[profile.activity] ?? 1.55;
  let aux = 0;
  const freq = profile.exerciseFrequency ?? "1-2";
  const work = profile.workLifestyle ?? "mixed";
  const exType = profile.exerciseType ?? "none";
  if (freq === "0") aux -= 0.05;
  else if (freq === "3-4") aux += 0.05;
  else if (freq === "5-6") aux += 0.10;
  else if (freq === "7") aux += 0.15;
  if (work === "sitting") aux -= 0.05;
  else if (work === "standing") aux += 0.05;
  else if (work === "heavy") aux += 0.10;
  if (exType === "gym" || exType === "cardio") aux += 0.05;
  factor = Math.max(1.20, Math.min(1.725, factor + aux));

  const tdee = Math.round(bmr * factor);
  const target = Math.round(tdee * 0.60);
  return {
    bmr, tdee, target,
    calorieGroup: findCalorieGroup(target),
    effectiveActivity: profile.activity ?? "moderate",
    effectiveFactor: factor,
    source: "local",
  };
}

// ── GPT-4o ilə kalori hesabı — proqram boyu tək cache ──
// Bu cache həm Onboarding-də, həm menu.ts-də eyni nəticəni verir
const _cache = new Map<string, CalorieResult>();

export function getCacheKey(profile: Profile): string {
  return JSON.stringify({
    gender: profile.gender,
    age: profile.age,
    height: profile.height,
    weight: profile.weight,
    activity: profile.activity,
    exerciseFrequency: profile.exerciseFrequency,
    exerciseType: profile.exerciseType,
    workLifestyle: profile.workLifestyle,
  });
}

export async function calcCaloriesGPT(profile: Profile): Promise<CalorieResult> {
  const cacheKey = getCacheKey(profile);
  if (_cache.has(cacheKey)) return _cache.get(cacheKey)!;

  const ageLabel: Record<AgeRange, string> = {
    "18-25": "18-25 yaş", "26-35": "26-35 yaş", "36-45": "36-45 yaş",
    "46-55": "46-55 yaş", "56+": "56+ yaş",
  };
  const weightLabel: Record<string, string> = {
    "40-60": "40-60 kq", "60-80": "60-80 kq", "80-100": "80-100 kq",
    "100-120": "100-120 kq", "120+": "120+ kq",
  };
  const heightLabel: Record<string, string> = {
    "140-160": "140-160 sm", "160-175": "160-175 sm",
    "175-190": "175-190 sm", "190+": "190+ sm",
  };
  const activityLabel: Record<string, string> = {
    sedentary: "oturaq (demək olar hərəkətsiz)",
    light: "az aktiv", moderate: "orta aktiv", active: "çox aktiv",
  };
  const freqLabel: Record<string, string> = {
    "0": "idman yoxdur", "1-2": "həftədə 1-2 gün", "3-4": "həftədə 3-4 gün",
    "5-6": "həftədə 5-6 gün", "7": "hər gün",
  };
  const workLabel: Record<string, string> = {
    sitting: "oturaq iş", mixed: "qarışıq (oturaq+hərəkət)",
    standing: "ayaqüstə iş", heavy: "fiziki ağır iş",
  };
  const exTypeLabel: Record<string, string> = {
    none: "yoxdur", walk: "gəzinti", home: "ev idmanı",
    gym: "fitnes/gym", cardio: "kardio", other: "digər",
  };

  const prompt = `Sən dəqiq kalori hesabı edən mütəxəssislərsən.
Aşağıdakı şəxsin məlumatlarına əsasən dəqiq TDEE hesabla:

- Cins: ${profile.gender === "woman" ? "Qadın" : "Kişi"}
- Yaş aralığı: ${ageLabel[profile.age]}
- Boy aralığı: ${heightLabel[profile.height]}
- Çəki aralığı: ${weightLabel[profile.weight]}
- Ümumi aktivlik səviyyəsi: ${activityLabel[profile.activity ?? "moderate"]}
- İdman tezliyi: ${freqLabel[profile.exerciseFrequency ?? "1-2"]}
- İdman növü: ${exTypeLabel[profile.exerciseType ?? "none"]}
- İş/gündəlik həyat tərzi: ${workLabel[profile.workLifestyle ?? "mixed"]}

Tapşırıq:
1. Aralıqların mərkəz nöqtəsini istifadə et (məs. 60-80 kq → 70 kq).
2. Mifflin-St Jeor düsturu ilə BMR hesabla.
3. Bütün aktivlik faktorlarını (idman tezliyi + növü + iş tərzi) nəzərə alaraq TDEE hesabla.
4. TDEE-nin 40%-ni çıx (40% defisit) → hədəf kalorini tap.

YALNIZ bu JSON formatında cavab ver, başqa heç nə yazma:
{"bmr": 1234, "tdee": 1678, "target": 1007, "factor": 1.55}`;

  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + API_KEY,
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }],
        temperature: 0,
        max_tokens: 80,
        response_format: { type: "json_object" },
      }),
    });

    if (!res.ok) throw new Error("GPT API: " + res.status);
    const data = await res.json();
    const parsed = JSON.parse(data.choices[0].message.content.trim()) as {
      bmr: number; tdee: number; target: number; factor: number;
    };

    const result: CalorieResult = {
      bmr: Math.round(parsed.bmr),
      tdee: Math.round(parsed.tdee),
      target: Math.round(parsed.target),
      calorieGroup: findCalorieGroup(Math.round(parsed.target)),
      effectiveActivity: profile.activity ?? "moderate",
      effectiveFactor: parsed.factor,
      source: "gpt",
    };
    _cache.set(cacheKey, result);
    return result;
  } catch {
    const fallback = localCalc(profile);
    _cache.set(cacheKey, fallback);
    return fallback;
  }
}

// ── menu.ts-dən çağırılır: cache varsa GPT nəticəsini, yoxsa lokal hesabı verir ──
// Bu funksiya sinxrondur — UI bloklanmır, GPT nəticəsi Onboarding-dən artıq cache-dədir
export function calcCalories(profile: Profile): CalorieResult {
  const cacheKey = getCacheKey(profile);
  if (_cache.has(cacheKey)) return _cache.get(cacheKey)!;
  // Cache yoxdursa (nadir hal) lokal hesab
  return localCalc(profile);
}

// Köhnə uyğunluq funksiyaları
export function calcBMR(gender: Gender, weightKg: number, heightCm: number, ageYr: number): number {
  const base = 10 * weightKg + 6.25 * heightCm - 5 * ageYr;
  return gender === "woman" ? base - 161 : base + 5;
}
export function determineEffectiveActivityLevel(profile: Profile) {
  return { level: profile.activity ?? "moderate" as ActivityLevel, factor: ACTIVITY_FACTORS[profile.activity ?? "moderate"] ?? 1.55 };
}
export function calcTDEE(bmr: number, factor: number): number { return bmr * factor; }
export function calcTargetCalories(tdee: number): number { return Math.round(tdee * 0.60); }
