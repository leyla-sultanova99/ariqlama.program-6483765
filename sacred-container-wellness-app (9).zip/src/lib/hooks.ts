import { useCallback } from "react";

/**
 * Haptic feedback via the Vibration API. Falls back silently on devices
 * that don't support it (iOS Safari, desktop). Used for the premium
 * "soft buzz" on key interactions.
 */
export function useHaptics() {
  const supported =
    typeof navigator !== "undefined" && typeof navigator.vibrate === "function";

  const vibrate = useCallback(
    (pattern: number | number[] = 8) => {
      if (!supported) return;
      try {
        navigator.vibrate(pattern);
      } catch {
        /* noop */
      }
    },
    [supported]
  );

  return { supported, vibrate };
}

/** True when the user prefers reduced motion (OS-level setting). */
export function usePrefersReducedMotion(): boolean {
  if (typeof window === "undefined" || !window.matchMedia) return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export const SPRING = { type: "spring", stiffness: 380, damping: 26 } as const;
export const SPRING_BOUNCE = { type: "spring", stiffness: 320, damping: 18, mass: 0.9 } as const;
export const EASE_OUT = [0.16, 1, 0.3, 1] as const;
