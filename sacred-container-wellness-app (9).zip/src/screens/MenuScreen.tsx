import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Card from "@/components/ui/Card";
import { Stagger, StaggerItem } from "@/components/ui/motion";
import AmbientParticles from "@/components/ui/AmbientParticles";
import DailyTips from "@/components/DailyTips";
import { dayMenu, type MealSlot } from "@/lib/menu";
import { useStore } from "@/lib/store";
import { useHaptics, EASE_OUT } from "@/lib/hooks";

const DAY_COUNT = 21;
const DAY_NAMES = Array.from({ length: DAY_COUNT }, (_, i) => `${i + 1}-ci gün`);
const DAY_START = 1;

/* ---------- Day indicator — 21 günlük sürüşdürülən strip ---------- */
function DayIndicator({
  selected,
  onSelect,
}: {
  selected: number;
  onSelect: (d: number) => void;
}) {
  const { vibrate } = useHaptics();
  const scrollRef = useRef<HTMLDivElement>(null);

  // Seçilən günü mərkəzə gətir
  useEffect(() => {
    if (scrollRef.current) {
      const el = scrollRef.current.querySelector(`[data-day="${selected}"]`) as HTMLElement | null;
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
      }
    }
  }, [selected]);

  return (
    <div
      ref={scrollRef}
      className="no-scrollbar flex gap-1.5 overflow-x-auto px-1 pt-1 pb-2"
      style={{ scrollSnapType: "x proximity" }}
    >
      {Array.from({ length: DAY_COUNT }, (_, i) => i + 1).map((d) => {
        const active = d === selected;
        return (
          <motion.button
            key={d}
            data-day={d}
            onClick={() => {
              if (!active) {
                vibrate(8);
                onSelect(d);
              }
            }}
            whileTap={{ scale: 0.9 }}
            className="relative flex shrink-0 flex-col items-center justify-center overflow-hidden"
            style={{
              width: 42,
              padding: "6px 4px",
              borderRadius: 14,
              cursor: "pointer",
              background: active ? undefined : "rgba(255,255,255,0.035)",
              boxShadow: active ? undefined : "inset 0 0 0 1px rgba(255,255,255,0.06)",
              scrollSnapAlign: "center",
            }}
          >
            {active && (
              <motion.span
                layoutId="day-pill"
                className="absolute inset-0"
                style={{
                  borderRadius: 14,
                  background: "linear-gradient(150deg, var(--accent), var(--accent-soft))",
                  boxShadow: "0 6px 16px rgba(251,206,177,0.4), inset 0 1px 0 rgba(255,255,255,0.5)",
                }}
                transition={{ type: "spring", stiffness: 420, damping: 34, mass: 0.6 }}
              />
            )}
            <motion.span
              animate={{ scale: active ? 1.08 : 1 }}
              transition={{ type: "spring", stiffness: 400, damping: 18 }}
              style={{
                position: "relative",
                fontSize: 13,
                fontWeight: 900,
                color: active ? "#1A1816" : "#F5E6D3",
                opacity: active ? 1 : 0.5,
                lineHeight: 1,
              }}
            >
              {d}
            </motion.span>
          </motion.button>
        );
      })}
    </div>
  );
}

/* ---------- Single meal with alternatives ---------- */
// Yemək adı mətnləri (izah cümləsində istifadə olunur).
const MEAL_NAME: Record<string, string> = {
  morning: "Səhər yeməyi",
  snack: "Qəlyanaltı",
  noon: "Günorta yeməyi",
  evening: "Axşam yeməyi",
};

/**
 * Dinamik izah mətni — hər yeməyin faktiki menyu sayına görə avtomatik uyğunlaşır.
 * 1 menyu → fərqli mətn, 2+ menyu → seçim sayına uyğun mətn.
 */
function instructionText(mealKey: string, count: number): string {
  const name = MEAL_NAME[mealKey] ?? "Bu yemək";
  if (count <= 1) {
    return `${name} üçün bu seçim sənin üçün hazırlanıb. Menyudakı BÜTÜN QİDALARI yeməlisən.`;
  }
  return (
    `${name} üçün ${count} seçim var. Onlardan BİRİNİ seç – və seçdiyin ` +
    `menyunun İÇİNDƏKİ BÜTÜN QİDALARI yeməlisən. Hamısı eyni dəstəyi verir, ` +
    `hansını seçsən fərqi yoxdur.`
  );
}

function MealCard({ meal, day }: { meal: MealSlot; day: number }) {
  const { getSelection, selectMeal } = useStore();
  const { vibrate } = useHaptics();
  const selected = getSelection(day, meal.key);
  const mealKcal = meal.kcal ?? 0;

  const hasSelection = selected !== undefined;

  return (
    <div className="space-y-3">
      <div>
        <div className="flex items-center gap-2">
          <h3 className="text-[16px] font-bold text-[var(--ink)]">{meal.title}</h3>
        </div>
        <p className="text-[13px] text-[var(--ink-dim)]">{meal.time}</p>
        {/* İzah mətni: seçim qaydası */}
        <div
          className="mt-2 rounded-[14px] p-3"
          style={{
            background: hasSelection
              ? "linear-gradient(135deg, rgba(251,206,177,0.10), rgba(245,184,149,0.03))"
              : "rgba(255,255,255,0.025)",
          }}
        >
          <p
            className="flex items-start gap-2 text-[13px] leading-relaxed"
            style={{ color: hasSelection ? "var(--accent)" : "var(--ink-dim)" }}
          >
            <span className="mt-0.5 shrink-0" style={{ fontSize: 13 }}>{hasSelection ? "✓" : "○"}</span>
            <span>
              {instructionText(meal.key, meal.options.length)}
            </span>
          </p>
        </div>
      </div>
      {meal.options.map((opt, id) => {
        const active = selected === id;
        return (
          <motion.button
            key={id}
            whileTap={{ scale: 0.97 }}
            whileHover={{ y: active ? -3 : -2, scale: 1.008 }}
            transition={{ type: "spring", stiffness: 360, damping: 24 }}
            onClick={() => {
              if (active) return;
              vibrate([8, 22, 8]);
              selectMeal(day, meal.key, id);
            }}
            className="shine-on-hover group flex w-full items-center gap-4 rounded-[20px] p-3 text-left"
            style={{
              transition: "transform 0.25s cubic-bezier(0.25,1,0.5,1), box-shadow 0.25s cubic-bezier(0.25,1,0.5,1), background 0.25s cubic-bezier(0.25,1,0.5,1)",
              background: active
                ? "linear-gradient(135deg, rgba(251,206,177,0.20), rgba(245,184,149,0.06))"
                : "rgba(245,230,211,0.035)",
              transform: active ? "translateY(-3px)" : "none",
              boxShadow: active
                ? "inset 0 0 0 1.5px rgba(251,206,177,0.6), 0 12px 30px rgba(251,206,177,0.16)"
                : "inset 0 0 0 1px rgba(255,255,255,0.04)",
            }}
          >
            <motion.span
              animate={{ scale: active ? 1.12 : 1, y: active ? -2 : 0 }}
              transition={{ type: "spring", stiffness: 320, damping: 18 }}
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/[0.05]"
              style={{ fontSize: 30, lineHeight: 1 }}
            >
              {opt.emoji}
            </motion.span>
            <span className="flex-1">
              <span
                className="block text-[15px] font-semibold"
                style={{ color: active ? "var(--accent)" : "var(--ink)" }}
              >
                {opt.name || "Menyu seçimi"}
              </span>
              <span
                className="text-[12px] font-medium"
                style={{ color: "var(--ink-dim)", opacity: active ? 0.9 : 0.6 }}
              >
                ~{mealKcal} kkal
              </span>
            </span>
            {/* Radio button indicator: həmişə görünən, seçiləndə dolu */}
            <span className="relative flex h-6 w-6 shrink-0 items-center justify-center">
              <span
                className="absolute rounded-full transition-all duration-300"
                style={{
                  width: 22,
                  height: 22,
                  border: `2px solid ${active ? "var(--accent)" : "rgba(245,230,211,0.3)"}`,
                  background: active ? "transparent" : "transparent",
                }}
              />
              <motion.span
                className="absolute rounded-full"
                animate={{ scale: active ? 1 : 0, opacity: active ? 1 : 0 }}
                transition={{ type: "spring", stiffness: 360, damping: 16 }}
                style={{
                  width: 12,
                  height: 12,
                  background: "linear-gradient(135deg, var(--accent), var(--accent-soft))",
                  boxShadow: "0 0 8px rgba(251,206,177,0.7)",
                }}
              />
            </span>
          </motion.button>
        );
      })}
    </div>
  );
}

export default function MenuScreen() {
  const { profile, weightNote, setWeightNote } = useStore();

  const [selectedDay, setSelectedDay] = useState(DAY_START);
  const menuDayIndex = selectedDay - DAY_START;

  const result = profile
    ? dayMenu(profile, menuDayIndex)
    : null;
  const meals = result?.meals ?? [];
  const flow = result?.flow ?? "Sənin axının";

  return (
    <div className="relative space-y-4">
      <AmbientParticles />
      <DayIndicator
        selected={selectedDay}
        onSelect={setSelectedDay}
      />

      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={selectedDay}
          className="smooth space-y-5"
          initial={{ opacity: 0, y: 18, filter: "blur(3px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          exit={{ opacity: 0, y: -10, filter: "blur(2px)" }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        >
            {/* Header */}
            <div className="px-1 pt-1">
            <h1 className="t-hero text-[30px] font-extrabold tracking-tight text-[var(--ink)]">
              {DAY_NAMES[selectedDay - DAY_START]} dəstəyi
            </h1>
              <p className="t-small mt-2 text-[var(--ink-dim)]">
                3 günlük İnci proqramın ·{" "}
                <span className="text-[var(--accent)]">{flow}</span>
              </p>
            </div>

            {/* Çəki qeyd bölməsi — yalnız gün 1-də, həmişə qalır */}
            {selectedDay === DAY_START && (
              <motion.div
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1, duration: 0.4, ease: EASE_OUT }}
                className="glass-soft rounded-[22px] p-4"
                style={{ boxShadow: "inset 0 0 0 1px rgba(251,206,177,0.18)" }}
              >
                <div className="flex items-start gap-3">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-[22px]"
                    style={{ background: "linear-gradient(135deg, rgba(251,206,177,0.25), rgba(245,184,149,0.06))" }}>
                    ⚖️
                  </span>
                  <div className="flex-1">
                    <p className="text-[15px] font-bold text-[var(--accent)]">
                      Çəkini qeyd et və sonra nəticəni müqayisə et
                    </p>
                    <textarea
                      value={weightNote}
                      onChange={(e) => setWeightNote(e.target.value)}
                      placeholder="Məsələn: 78.5 kq — 1-ci gün səhər"
                      rows={2}
                      maxLength={100}
                      className="mt-2 w-full resize-none rounded-[16px] p-3 text-[14px] text-[var(--ink)] placeholder:text-[var(--ink-faint)] focus:outline-none"
                      style={{
                        background: "rgba(255,255,255,0.03)",
                        boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.06)",
                        color: "var(--ink)",
                      }}
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* Menu card */}
            <Card hover>
              <Stagger className="space-y-5">
                {meals.map((meal) => (
                  <StaggerItem key={meal.key}>
                    <MealCard meal={meal} day={selectedDay} />
                  </StaggerItem>
                ))}
              </Stagger>
            </Card>

            {/* Daily scientific recommendations */}
            <DailyTips delay={0.1} />
          </motion.div>
      </AnimatePresence>
    </div>
  );
}
