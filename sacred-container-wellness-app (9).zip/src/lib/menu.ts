import type { Profile } from "@/lib/store";
import { calcCalories, type CalorieGroup } from "@/lib/calories";
import {
  buildDayForCalorieGroup,
  kcalForCalorieGroup,
  portionLabelForCalorieGroup,
  portionLabel,
  getLevelKcal,
  type Level,
  type MealSlot,
} from "@/lib/menuTemplates";
import type { CalorieGroupKey } from "@/lib/groupMenuData";

/* =====================================================================
   DÜZGÜN MENYU SİSTEMİ — 7 qrup × 30 unikal gün = 210 gün
   Köhnə 5-səviyyəli (A–E) + 3-günlük təkrarlama sistemi QALDIRILIB.
   İstifadəçinin kalori qrupuna (7 qrupdan birinin açarına) uyğun
   groupMenuData.ts-dəki həqiqi 30-günlük menyu verilir.
==================================================================== */

export type { DayMenu, MealSlot, Dish, Level } from "@/lib/menuTemplates";
export { portionLabel, getLevelKcal };

export interface DayMenuResult {
  meals: MealSlot[];
  groupKey: CalorieGroupKey;
  kcal: number;
  portion: string;
  flow: string;
  calorieGroup: CalorieGroup | null;
  target: number;
  /** köhnə Level tipi ilə geriyə uyğunluq üçün saxlanılır */
  level: Level;
}

export function flowName(p: Profile): string {
  const young = p.age === "18-25" || p.age === "26-35";
  if (p.gender === "woman") return young ? "Gənc qadın axını" : "Dərin bərpa axını";
  return young ? "Aktif axın" : "Sakit bərpa axını";
}

/** CalorieGroup.key ("1200_1299" formatı) → CalorieGroupKey */
function toGroupKey(group: CalorieGroup | null): CalorieGroupKey {
  if (!group) return "1200_1299";
  return group.key as CalorieGroupKey;
}

/**
 * Geriyə uyğunluq üçün Level qaytarır — köhnə kodun Level istifadə etdiyi
 * yerlərdə xəta verməmək üçün. Yeni kod groupKey istifadə etməlidir.
 */
function groupKeyToLevel(gk: CalorieGroupKey): Level {
  const map: Record<CalorieGroupKey, Level> = {
    "1200_1299": "A",
    "1300_1399": "B",
    "1400_1499": "C",
    "1500_1599": "C",
    "1600_1699": "D",
    "1700_1799": "E",
    "1800_1899": "E",
  };
  return map[gk] ?? "A";
}

/**
 * Verilən profil və günə uyğun menyunu qaytarır.
 * Artıq köhnə A–E/3-günlük sistem deyil — 7 qrupun hər birinin
 * həqiqi 30 unikal günü istifadə olunur.
 */
export function dayMenu(profile: Profile, day: number): DayMenuResult {
  const { target, calorieGroup } = calcCalories(profile);
  const restriction = profile.restriction ?? "none";
  const groupKey = toGroupKey(calorieGroup);
  const meals = buildDayForCalorieGroup(groupKey, day, restriction);
  return {
    meals,
    groupKey,
    level: groupKeyToLevel(groupKey),
    kcal: kcalForCalorieGroup(groupKey),
    portion: portionLabelForCalorieGroup(groupKey),
    flow: flowName(profile),
    calorieGroup,
    target,
  };
}
