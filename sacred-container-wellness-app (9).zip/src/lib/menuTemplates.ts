import type { Restriction } from "@/lib/store";
import { GROUP_MENUS, type CalorieGroupKey } from "@/lib/groupMenuData";

/* =====================================================================
   İNCİ — 3 GÜNLÜK MENYU (5 SƏVİYYƏ: A, B, C, D, E)
   Tamamilə hardcoded qida məlumatları — heç bir generator YOXDUR.
==================================================================== */

export type Level = "A" | "B" | "C" | "D" | "E";

export interface Dish {
  emoji: string;
  name: string;
}

export interface MealSlot {
  key: string;
  title: string;
  time: string;
  kcal: number;
  options: Dish[];
}

export type DayMenu = MealSlot[];

const META = [
  { key: "morning", title: "Səhər dəstəyi", time: "oyandıqdan sonra" },
  { key: "snack", title: "Səhər qəlyanaltı", time: "səhər saatları" },
  { key: "noon", title: "Günorta dəstəyi", time: "günün ortası" },
  { key: "snack2", title: "Günün ortası qəlyanaltı", time: "günün ikinci yarısı" },
  { key: "evening", title: "Axşam bərpası", time: "sakitləşmə vaxtı" },
];

type RawMeal = { kcal: number; opts: [string, string][] };

function makeDay(meals: RawMeal[]): DayMenu {
  return meals.map((m, i) => ({
    ...META[i],
    kcal: m.kcal,
    options: m.opts.map(([emoji, name]) => ({ emoji, name })),
  }));
}

/* ============ SƏVİYYƏ A (800 kkal) ============ */
const LEVEL_A: DayMenu[] = [
  // Gün 1
  makeDay([
    { kcal: 220, opts: [
      ["🍳", "2 ədəd qaynadılmış yumurta (120 q) + 1 ədəd tam buğda çörəyi (30 q) + 1 ədəd pomidor (100 q)"],
      ["🧀", "150 q kəsmik (az yağlı) + 1 ədəd xiyar (150 q)"],
      ["🥣", "1 stəkan (200 ml) kefir (1%) + 1 y.q. yulaf (15 q) + 1 ədəd alma (150 q)"],
    ]},
    { kcal: 40, opts: [
      ["🥒", "1 ədəd xiyar (150 q)"],
      ["🥛", "1 stəkan (200 ml) ayran"],
      ["🥕", "1 ədəd yerkökü (100 q)"],
    ]},
    { kcal: 280, opts: [
      ["🍗", "150 q toyuq göğsü (bişmiş) + 200 q salat (pomidor, xiyar, kahı) + 1 ç.q. zeytun yağı"],
      ["🍲", "1 boşqab (300 ml) tərəvəz şorbası (kartofsuz) + 1 ədəd çörək (20 q)"],
      ["🍳", "2 ədəd qaynadılmış yumurta (120 q) + 1 pomidor + 1 xiyar"],
    ]},
    { kcal: 40, opts: [
      ["🍎", "1 ədəd alma (150 q)"],
      ["🍊", "1 ədəd portağal (150 q)"],
      ["🥛", "1 stəkan (200 ml) ayran"],
    ]},
    { kcal: 220, opts: [
      ["🐟", "150 q balıq (bişmiş) + 150 q buxarda tərəvəz (brokoli, yerkökü)"],
      ["🥬", "200 q kələm dolması (1 ədəd) + 1 ədəd çörək (15 q)"],
      ["🥘", "1 boşqab (200 q) tərəvəz güveç (kartofsuz) + 1 y.q. qatıq (20 q)"],
    ]},
  ]),
  // Gün 2
  makeDay([
    { kcal: 220, opts: [
      ["🍳", "2 ədəd ispanaqlı omlet (yağsız) + 1 ədəd çörək (30 q)"],
      ["🧀", "150 q kəsmik + 1 ədəd armud (150 q)"],
      ["🥣", "1 stəkan (200 ml) süd (1%) + 1 y.q. yulaf (15 q) + 1 ç.q. bal (5 q)"],
    ]},
    { kcal: 40, opts: [
      ["🍐", "1 ədəd armud (150 q)"],
      ["🥒", "1 ədəd xiyar (150 q)"],
      ["🥛", "1 stəkan (200 ml) ayran"],
    ]},
    { kcal: 280, opts: [
      ["🍗", "150 q toyuq + 200 q salat + 1 ç.q. zeytun yağı"],
      ["🍲", "1 boşqab (300 ml) mərcimək şorbası (yağsız) + 1 ədəd çörək (20 q)"],
      ["🍳", "2 ədəd yumurta + 1 pomidor + 1 xiyar"],
    ]},
    { kcal: 40, opts: [
      ["🍎", "1 ədəd alma (150 q)"],
      ["🥕", "1 ədəd yerkökü (100 q)"],
      ["🥛", "1 stəkan (200 ml) kefir"],
    ]},
    { kcal: 220, opts: [
      ["🐟", "150 q balıq + 150 q buxarda tərəvəz"],
      ["🥬", "250 q kələm dolması (2 ədəd) + 1 ədəd çörək (15 q)"],
      ["🥘", "1 boşqab (200 q) tərəvəz güveç + 1 y.q. qatıq"],
    ]},
  ]),
  // Gün 3
  makeDay([
    { kcal: 220, opts: [
      ["🍳", "2 ədəd qaynadılmış yumurta + 1 ədəd çörək (30 q) + 1 pomidor"],
      ["🧀", "150 q kəsmik + 1 ədəd banan (100 q)"],
      ["🥣", "1 stəkan (200 ml) kefir + 1 y.q. yulaf (15 q) + 1 alma (150 q)"],
    ]},
    { kcal: 40, opts: [
      ["🍊", "1 ədəd portağal (150 q)"],
      ["🥒", "1 ədəd xiyar (150 q)"],
      ["🥛", "1 stəkan (200 ml) ayran"],
    ]},
    { kcal: 280, opts: [
      ["🍗", "150 q toyuq + 200 q salat + 1 ç.q. zeytun yağı"],
      ["🍲", "1 boşqab (300 ml) tərəvəz şorbası + 1 çörək (20 q)"],
      ["🍳", "2 yumurta + 1 pomidor + 1 xiyar"],
    ]},
    { kcal: 40, opts: [
      ["🍐", "1 armud (150 q)"],
      ["🥕", "1 yerkökü (100 q)"],
      ["🥛", "1 stəkan kefir"],
    ]},
    { kcal: 220, opts: [
      ["🐟", "150 q balıq + 150 q buxarda tərəvəz"],
      ["🥬", "200 q kələm dolması (1 ədəd) + 1 çörək (15 q)"],
      ["🥘", "1 boşqab tərəvəz güveç + 1 qaşıq qatıq"],
    ]},
  ]),
];

/* ============ SƏVİYYƏ B (900 kkal) ============ */
const LEVEL_B: DayMenu[] = [
  // Gün 1
  makeDay([
    { kcal: 250, opts: [
      ["🍳", "2 yumurta + 1 çörək (40 q) + 1 pomidor + 1 xiyar + 30 q pendir"],
      ["🧀", "200 q kəsmik + 1 alma (150 q) + 1 çörək (20 q)"],
      ["🥣", "1 stəkan süd + 2 y.q. yulaf (30 q) + 1 ç.q. bal + 1 banan (100 q)"],
    ]},
    { kcal: 50, opts: [
      ["🍎", "1 ədəd alma (150 q)"],
      ["🍐", "1 ədəd armud (150 q)"],
      ["🥛", "1 stəkan kefir"],
    ]},
    { kcal: 320, opts: [
      ["🍗", "180 q toyuq + 200 q salat + 1 ç.q. zeytun yağı + 1 çörək (20 q)"],
      ["🍲", "1 boşqab (350 ml) mərcimək şorbası + 1 çörək (30 q)"],
      ["🍳", "3 yumurta + 1 pomidor + 1 xiyar + 1 çörək (20 q)"],
    ]},
    { kcal: 50, opts: [
      ["🍊", "1 portağal (150 q)"],
      ["🥕", "1 yerkökü (100 q)"],
      ["🥛", "1 stəkan ayran"],
    ]},
    { kcal: 280, opts: [
      ["🐟", "180 q balıq + 180 q buxarda tərəvəz + 1 çörək (20 q)"],
      ["🥬", "250 q kələm dolması (2 ədəd) + 1 çörək (20 q)"],
      ["🥘", "1 boşqab (250 q) tərəvəz güveç + qatıq + 1 çörək (15 q)"],
    ]},
  ]),
  // Gün 2
  makeDay([
    { kcal: 250, opts: [
      ["🍳", "2 ispanaqlı omlet + 1 çörək (40 q) + 30 q pendir"],
      ["🧀", "200 q kəsmik + 1 banan + 1 çörək (20 q) + bal"],
      ["🥣", "1 stəkan süd + 2 y.q. yulaf (30 q) + bal + 1 alma"],
    ]},
    { kcal: 50, opts: [
      ["🍐", "1 armud (150 q)"],
      ["🥒", "1 xiyar (150 q)"],
      ["🥛", "1 stəkan ayran"],
    ]},
    { kcal: 320, opts: [
      ["🍗", "180 q toyuq + 200 q salat + zeytun yağı + 1 çörək (20 q)"],
      ["🍲", "1 boşqab (350 ml) tərəvəz şorbası + 1 çörək (30 q)"],
      ["🍳", "3 yumurta + 1 pomidor + 1 xiyar + 1 çörək (20 q)"],
    ]},
    { kcal: 50, opts: [
      ["🍎", "1 alma (150 q)"],
      ["🥕", "1 yerkökü (100 q)"],
      ["🥛", "1 stəkan kefir"],
    ]},
    { kcal: 280, opts: [
      ["🐟", "180 q balıq + 180 q buxarda tərəvəz + 1 çörək (20 q)"],
      ["🥬", "300 q kələm dolması (2 ədəd) + 1 çörək"],
      ["🥘", "1 boşqab (250 q) tərəvəz güveç + qatıq + 1 çörək"],
    ]},
  ]),
  // Gün 3
  makeDay([
    { kcal: 250, opts: [
      ["🍳", "2 qaynadılmış yumurta + 1 çörək (40 q) + 1 pomidor + 30 q pendir"],
      ["🧀", "200 q kəsmik + 1 portağal + 1 çörək (20 q)"],
      ["🥣", "1 stəkan kefir + 2 y.q. yulaf (30 q) + bal + 1 banan"],
    ]},
    { kcal: 50, opts: [
      ["🍊", "1 portağal (150 q)"],
      ["🥒", "1 xiyar (150 q)"],
      ["🥛", "1 stəkan ayran"],
    ]},
    { kcal: 320, opts: [
      ["🍗", "180 q toyuq + 200 q salat + zeytun yağı + 1 çörək"],
      ["🍲", "1 boşqab mərcimək şorbası + 1 çörək (30 q)"],
      ["🍳", "3 yumurta + 1 pomidor + 1 xiyar + 1 çörək"],
    ]},
    { kcal: 50, opts: [
      ["🍎", "1 alma"],
      ["🍐", "1 armud"],
      ["🥛", "1 stəkan kefir"],
    ]},
    { kcal: 280, opts: [
      ["🐟", "180 q balıq + 180 q buxarda tərəvəz + 1 çörək"],
      ["🥬", "250 q kələm dolması (2 ədəd) + 1 çörək"],
      ["🥘", "1 boşqab tərəvəz güveç + qatıq + 1 çörək"],
    ]},
  ]),
];

/* ============ SƏVİYYƏ C (1050 kkal) ============ */
const LEVEL_C: DayMenu[] = [
  makeDay([
    { kcal: 300, opts: [
      ["🍳", "2 yumurta + 1 çörək (50 q) + 1 pomidor + 1 xiyar + 30 q pendir"],
      ["🧀", "200 q kəsmik + 1 banan + 1 çörək (30 q) + bal"],
      ["🥣", "1 stəkan süd + 2 y.q. yulaf + bal + 1 alma + 1 qoz (10 q)"],
    ]},
    { kcal: 70, opts: [
      ["🍎", "1 alma + 1 qoz"],
      ["🍐", "1 armud + 1 qoz"],
      ["🥛", "1 stəkan kefir + 1 çörək (15 q)"],
    ]},
    { kcal: 380, opts: [
      ["🍗", "200 q toyuq + 200 q salat + zeytun yağı + 1 çörək (30 q)"],
      ["🍲", "1 boşqab (400 ml) lobya şorbası + 1 çörək (30 q)"],
      ["🍳", "3 yumurta + 1 pomidor + 1 xiyar + 1 çörək (30 q)"],
    ]},
    { kcal: 70, opts: [
      ["🍊", "1 portağal + 1 qoz"],
      ["🥕", "1 yerkökü + 1 qoz"],
      ["🥛", "1 stəkan ayran + 1 çörək (15 q)"],
    ]},
    { kcal: 300, opts: [
      ["🐟", "200 q balıq + 200 q buxarda tərəvəz + 1 çörək (30 q)"],
      ["🥬", "300 q kələm dolması (3 ədəd) + 1 çörək (20 q)"],
      ["🥘", "1 boşqab (300 q) tərəvəz güveç + qatıq + 1 çörək (20 q)"],
    ]},
  ]),
  makeDay([
    { kcal: 300, opts: [
      ["🍳", "2 ispanaqlı omlet + 1 çörək (50 q) + 30 q pendir + 1 pomidor"],
      ["🧀", "200 q kəsmik + 1 alma + 1 çörək (30 q) + bal"],
      ["🥣", "1 stəkan süd + 2 y.q. yulaf + bal + 1 banan + 1 qoz"],
    ]},
    { kcal: 70, opts: [
      ["🍐", "1 armud + 1 qoz"],
      ["🍎", "1 alma + 1 qoz"],
      ["🥛", "1 stəkan kefir + 1 çörək (15 q)"],
    ]},
    { kcal: 380, opts: [
      ["🍗", "200 q toyuq + 200 q salat + zeytun yağı + 1 çörək (30 q)"],
      ["🍲", "1 boşqab (400 ml) mərcimək şorbası + 1 çörək (30 q)"],
      ["🍳", "3 yumurta + 1 pomidor + 1 xiyar + 1 çörək (30 q)"],
    ]},
    { kcal: 70, opts: [
      ["🍊", "1 portağal + 1 qoz"],
      ["🥕", "1 yerkökü + 1 qoz"],
      ["🥛", "1 stəkan ayran + 1 çörək (15 q)"],
    ]},
    { kcal: 300, opts: [
      ["🐟", "200 q balıq + 200 q buxarda tərəvəz + 1 çörək (30 q)"],
      ["🥬", "300 q kələm dolması (3 ədəd) + 1 çörək (20 q)"],
      ["🥘", "1 boşqab tərəvəz güveç + qatıq + 1 çörək (20 q)"],
    ]},
  ]),
  makeDay([
    { kcal: 300, opts: [
      ["🍳", "2 qaynadılmış yumurta + 1 çörək (50 q) + 1 pomidor + 30 q pendir"],
      ["🧀", "200 q kəsmik + 1 portağal + 1 çörək (30 q) + bal"],
      ["🥣", "1 stəkan kefir + 2 y.q. yulaf + bal + 1 banan + 1 qoz"],
    ]},
    { kcal: 70, opts: [
      ["🍎", "1 alma + 1 qoz"],
      ["🍊", "1 portağal + 1 qoz"],
      ["🥛", "1 stəkan kefir + 1 çörək (15 q)"],
    ]},
    { kcal: 380, opts: [
      ["🍗", "200 q toyuq + 200 q salat + zeytun yağı + 1 çörək (30 q)"],
      ["🍲", "1 boşqab lobya şorbası + 1 çörək (30 q)"],
      ["🍳", "3 yumurta + 1 pomidor + 1 xiyar + 1 çörək (30 q)"],
    ]},
    { kcal: 70, opts: [
      ["🍐", "1 armud + 1 qoz"],
      ["🥕", "1 yerkökü + 1 qoz"],
      ["🥛", "1 stəkan ayran + 1 çörək (15 q)"],
    ]},
    { kcal: 300, opts: [
      ["🐟", "200 q balıq + 200 q buxarda tərəvəz + 1 çörək (30 q)"],
      ["🥬", "300 q kələm dolması (3 ədəd) + 1 çörək"],
      ["🥘", "1 boşqab tərəvəz güveç + qatıq + 1 çörək"],
    ]},
  ]),
];

/* ============ SƏVİYYƏ D (1000 kkal) — Kişi ============ */
const LEVEL_D: DayMenu[] = [
  makeDay([
    { kcal: 280, opts: [
      ["🍳", "2 yumurta + 1 çörək (40 q) + 1 pomidor + 1 xiyar + 30 q pendir"],
      ["🧀", "200 q kəsmik + 1 banan + 1 çörək (30 q) + bal"],
      ["🥣", "1 stəkan süd + 2 y.q. yulaf + bal + 1 alma + 1 qoz"],
    ]},
    { kcal: 70, opts: [
      ["🍎", "1 alma + 2 qoz"],
      ["🍐", "1 armud + 2 qoz"],
      ["🥛", "1 stəkan kefir + 1 çörək (20 q)"],
    ]},
    { kcal: 370, opts: [
      ["🍗", "200 q toyuq + 200 q salat + zeytun yağı + 1 çörək (30 q)"],
      ["🍲", "1 boşqab (400 ml) mərcimək şorbası + 1 çörək (40 q)"],
      ["🍳", "3 yumurta + 1 pomidor + 1 xiyar + 1 çörək (30 q)"],
    ]},
    { kcal: 70, opts: [
      ["🍊", "1 portağal + 2 qoz"],
      ["🥕", "1 yerkökü + 2 qoz"],
      ["🥛", "1 stəkan ayran + 1 çörək (20 q)"],
    ]},
    { kcal: 300, opts: [
      ["🐟", "200 q balıq + 200 q buxarda tərəvəz + 1 çörək (30 q)"],
      ["🥬", "300 q kələm dolması (3 ədəd) + 1 çörək (30 q)"],
      ["🥘", "1 boşqab (300 q) tərəvəz güveç + qatıq + 1 çörək (20 q)"],
    ]},
  ]),
  makeDay([
    { kcal: 280, opts: [
      ["🍳", "2 ispanaqlı omlet + 1 çörək (40 q) + 30 q pendir + 1 pomidor"],
      ["🧀", "200 q kəsmik + 1 armud + 1 çörək (30 q) + bal"],
      ["🥣", "1 stəkan süd + 2 y.q. yulaf + bal + 1 banan + 1 qoz"],
    ]},
    { kcal: 70, opts: [
      ["🍎", "1 alma + 2 qoz"],
      ["🍐", "1 armud + 2 qoz"],
      ["🥛", "1 stəkan kefir + 1 çörək (20 q)"],
    ]},
    { kcal: 370, opts: [
      ["🍗", "200 q toyuq + 200 q salat + zeytun yağı + 1 çörək (30 q)"],
      ["🍲", "1 boşqab (400 ml) tərəvəz şorbası + 1 çörək (40 q)"],
      ["🍳", "3 yumurta + 1 pomidor + 1 xiyar + 1 çörək (30 q)"],
    ]},
    { kcal: 70, opts: [
      ["🍊", "1 portağal + 2 qoz"],
      ["🥕", "1 yerkökü + 2 qoz"],
      ["🥛", "1 stəkan ayran + 1 çörək (20 q)"],
    ]},
    { kcal: 300, opts: [
      ["🐟", "200 q balıq + 200 q buxarda tərəvəz + 1 çörək (30 q)"],
      ["🥬", "300 q kələm dolması (3 ədəd) + 1 çörək"],
      ["🥘", "1 boşqab tərəvəz güveç + qatıq + 1 çörək"],
    ]},
  ]),
  makeDay([
    { kcal: 280, opts: [
      ["🍳", "2 qaynadılmış yumurta + 1 çörək (40 q) + 1 pomidor + 30 q pendir"],
      ["🧀", "200 q kəsmik + 1 portağal + 1 çörək (30 q) + bal"],
      ["🥣", "1 stəkan kefir + 2 y.q. yulaf + bal + 1 alma + 1 qoz"],
    ]},
    { kcal: 70, opts: [
      ["🍎", "1 alma + 2 qoz"],
      ["🍊", "1 portağal + 2 qoz"],
      ["🥛", "1 stəkan kefir + 1 çörək (20 q)"],
    ]},
    { kcal: 370, opts: [
      ["🍗", "200 q toyuq + 200 q salat + zeytun yağı + 1 çörək (30 q)"],
      ["🍲", "1 boşqab mərcimək şorbası + 1 çörək (40 q)"],
      ["🍳", "3 yumurta + 1 pomidor + 1 xiyar + 1 çörək (30 q)"],
    ]},
    { kcal: 70, opts: [
      ["🍐", "1 armud + 2 qoz"],
      ["🥕", "1 yerkökü + 2 qoz"],
      ["🥛", "1 stəkan ayran + 1 çörək (20 q)"],
    ]},
    { kcal: 300, opts: [
      ["🐟", "200 q balıq + 200 q buxarda tərəvəz + 1 çörək (30 q)"],
      ["🥬", "300 q kələm dolması (3 ədəd) + 1 çörək"],
      ["🥘", "1 boşqab tərəvəz güveç + qatıq + 1 çörək"],
    ]},
  ]),
];

/* ============ SƏVİYYƏ E (1200 kkal) — Kişi ============ */
const LEVEL_E: DayMenu[] = [
  makeDay([
    { kcal: 320, opts: [
      ["🍳", "3 yumurta + 1 çörək (50 q) + 1 pomidor + 1 xiyar + 40 q pendir + 1 qoz"],
      ["🧀", "250 q kəsmik + 1 banan + 1 çörək (40 q) + bal + 1 qoz"],
      ["🥣", "1 stəkan süd + 3 y.q. yulaf + bal + 1 alma + 1 armud + 1 qoz"],
    ]},
    { kcal: 80, opts: [
      ["🍎", "1 alma + 2 qoz"],
      ["🍐", "1 armud + 2 qoz"],
      ["🥛", "1 stəkan kefir + 1 çörək (20 q)"],
    ]},
    { kcal: 420, opts: [
      ["🍗", "220 q toyuq + 200 q salat + zeytun yağı + 1 çörək (40 q)"],
      ["🍲", "1 boşqab (450 ml) lobya şorbası + 1 çörək (40 q)"],
      ["🍳", "4 yumurta + 1 pomidor + 1 xiyar + 1 çörək (40 q)"],
    ]},
    { kcal: 80, opts: [
      ["🍊", "1 portağal + 2 qoz"],
      ["🥕", "1 yerkökü + 2 qoz"],
      ["🥛", "1 stəkan ayran + 1 çörək (20 q)"],
    ]},
    { kcal: 350, opts: [
      ["🐟", "220 q balıq + 200 q buxarda tərəvəz + 1 çörək (40 q)"],
      ["🥬", "350 q kələm dolması (4 ədəd) + 1 çörək (30 q)"],
      ["🥘", "1 boşqab (350 q) tərəvəz güveç + qatıq + 1 çörək (30 q)"],
    ]},
  ]),
  makeDay([
    { kcal: 320, opts: [
      ["🍳", "3 ispanaqlı omlet + 1 çörək (50 q) + 40 q pendir + 1 pomidor"],
      ["🧀", "250 q kəsmik + 1 alma + 1 çörək (40 q) + bal + 1 qoz"],
      ["🥣", "1 stəkan süd + 3 y.q. yulaf + bal + 1 banan + 1 armud + 1 qoz"],
    ]},
    { kcal: 80, opts: [
      ["🍎", "1 alma + 2 qoz"],
      ["🍐", "1 armud + 2 qoz"],
      ["🥛", "1 stəkan kefir + 1 çörək (20 q)"],
    ]},
    { kcal: 420, opts: [
      ["🍗", "220 q toyuq + 200 q salat + zeytun yağı + 1 çörək (40 q)"],
      ["🍲", "1 boşqab (450 ml) mərcimək şorbası + 1 çörək (40 q)"],
      ["🍳", "4 yumurta + 1 pomidor + 1 xiyar + 1 çörək (40 q)"],
    ]},
    { kcal: 80, opts: [
      ["🍊", "1 portağal + 2 qoz"],
      ["🥕", "1 yerkökü + 2 qoz"],
      ["🥛", "1 stəkan ayran + 1 çörək (20 q)"],
    ]},
    { kcal: 350, opts: [
      ["🐟", "220 q balıq + 200 q buxarda tərəvəz + 1 çörək (40 q)"],
      ["🥬", "350 q kələm dolması (4 ədəd) + 1 çörək"],
      ["🥘", "1 boşqab tərəvəz güveç + qatıq + 1 çörək"],
    ]},
  ]),
  makeDay([
    { kcal: 320, opts: [
      ["🍳", "3 qaynadılmış yumurta + 1 çörək (50 q) + 1 pomidor + 40 q pendir + 1 qoz"],
      ["🧀", "250 q kəsmik + 1 portağal + 1 çörək (40 q) + bal + 1 qoz"],
      ["🥣", "1 stəkan kefir + 3 y.q. yulaf + bal + 1 alma + 1 banan + 1 qoz"],
    ]},
    { kcal: 80, opts: [
      ["🍎", "1 alma + 2 qoz"],
      ["🍊", "1 portağal + 2 qoz"],
      ["🥛", "1 stəkan kefir + 1 çörək (20 q)"],
    ]},
    { kcal: 420, opts: [
      ["🍗", "220 q toyuq + 200 q salat + zeytun yağı + 1 çörək (40 q)"],
      ["🍲", "1 boşqab lobya şorbası + 1 çörək (40 q)"],
      ["🍳", "4 yumurta + 1 pomidor + 1 xiyar + 1 çörək (40 q)"],
    ]},
    { kcal: 80, opts: [
      ["🍐", "1 armud + 2 qoz"],
      ["🥕", "1 yerkökü + 2 qoz"],
      ["🥛", "1 stəkan ayran + 1 çörək (20 q)"],
    ]},
    { kcal: 350, opts: [
      ["🐟", "220 q balıq + 200 q buxarda tərəvəz + 1 çörək (40 q)"],
      ["🥬", "350 q kələm dolması (4 ədəd) + 1 çörək"],
      ["🥘", "1 boşqab tərəvəz güveç + qatıq + 1 çörək"],
    ]},
  ]),
];

const ALL_LEVELS: Record<Level, DayMenu[]> = {
  A: LEVEL_A,
  B: LEVEL_B,
  C: LEVEL_C,
  D: LEVEL_D,
  E: LEVEL_E,
};

const LEVEL_KCAL: Record<Level, number> = {
  A: 800,
  B: 950,
  C: 1100,
  D: 1050,
  E: 1250,
};

export function isAllowed(name: string, restriction: Restriction): boolean {
  if (restriction === "none") return true;
  if (restriction === "dairy-free") return !/kəsmik|süd|kefir|ayran|qatıq|pendir/i.test(name);
  if (restriction === "bread-free") return !/çörək|yulaf/i.test(name);
  if (restriction === "meat-free") return !/toyuq|balıq|mal əti/i.test(name);
  if (restriction === "egg-free") return !/yumurta|omlet/i.test(name);
  return true;
}

export function buildDay(
  level: Level,
  day: number,
  restriction: Restriction
): DayMenu {
  const menus = ALL_LEVELS[level] ?? LEVEL_A;
  const dayMenu = menus[((day % 3) + 3) % 3] ?? menus[0];

  if (restriction === "none") return dayMenu;

  return dayMenu.map((meal) => {
    const filtered = meal.options.filter((o) => isAllowed(o.name, restriction));
    return {
      ...meal,
      options: filtered.length > 0 ? filtered : meal.options,
    };
  });
}

export function getLevelKcal(level: Level): number {
  return LEVEL_KCAL[level] ?? 800;
}

export function portionLabel(level: Level): string {
  const labels: Record<Level, string> = {
    A: "yüngül porsiya",
    B: "tarazlı porsiya",
    C: "dolu porsiya",
    D: "dəstəkləyici porsiya",
    E: "tam porsiya",
  };
  return labels[level] ?? "tarazlı porsiya";
}

/* =====================================================================
   DÜZGÜN SİSTEM: hər bir kalori qrupunun (7 qrupun HƏR BİRİNİN) öz
   həqiqi 30 günlük menyusu var — köhnə 5-səviyyəli (A–E) sistemin
   yerinə. groupMenuData.ts-dəki 7×30 = 210 unikal gün buradan istifadə
   olunur. Köhnə buildDay/Level sistemi YUXARIDA silinmədən qalır.
==================================================================== */
export function buildDayForCalorieGroup(
  groupKey: CalorieGroupKey,
  day: number,
  restriction: Restriction
): DayMenu {
  const days = GROUP_MENUS[groupKey] ?? GROUP_MENUS["1200_1299"];
  // gün 1-30 arası dövr edir (30-dan çox proqram günü olsa belə)
  const idx = ((day - 1) % 21 + 21) % 21;
  const dayMenu = days[idx] ?? days[0];

  if (restriction === "none") return dayMenu;

  return dayMenu.map((meal) => {
    const filtered = meal.options.filter((o) => isAllowed(o.name, restriction));
    return {
      ...meal,
      options: filtered.length > 0 ? filtered : meal.options,
    };
  });
}

/** Kalori qrupunun təxmini gündəlik kalori dəyəri (aralığın ortası) — göstərmək üçün. */
export function kcalForCalorieGroup(groupKey: CalorieGroupKey): number {
  const [lo, hi] = groupKey.split("_").map(Number);
  return Math.round((lo + hi) / 2);
}

/** Kalori qrupuna uyğun porsiya adı — aşağıdan yuxarıya 7 səviyyə. */
export function portionLabelForCalorieGroup(groupKey: CalorieGroupKey): string {
  const labels: Record<CalorieGroupKey, string> = {
    "1200_1299": "yüngül porsiya",
    "1300_1399": "yüngül-tarazlı porsiya",
    "1400_1499": "tarazlı porsiya",
    "1500_1599": "tarazlı-dolu porsiya",
    "1600_1699": "dolu porsiya",
    "1700_1799": "geniş porsiya",
    "1800_1899": "ən geniş porsiya",
  };
  return labels[groupKey] ?? "tarazlı porsiya";
}
