/* =================== BACKGROUND — AI DIETITIAN templates =================== */
// Used silently by the voice system. Not displayed on the simplified page.

export interface DoctorTopic {
  key: string;
  keywords: string[];
  response: string;
}

export const doctorTopics: DoctorTopic[] = [
  {
    key: "bloating",
    keywords: ["şiş", "şişkin", "shish", "bloat", "qarın", "qaz"],
    response:
      "Bir az ilıq su iç və yavaş-yavaş yumşaq hərəkət et. Bədənin sənə siqnal verir, səni qoruyur. Gəl dörd sanəyə dərin nəfəs alaq.",
  },
  {
    key: "headache",
    keywords: ["baş", "bas", "ağrı", "agri", "headache", "migren"],
    response:
      "İlk addım — su. Sonra beş dəqiqəlik sakit bir künc. Bədənin dincəlmək istəyir, ona bu icazəni ver.",
  },
  {
    key: "stress",
    keywords: ["stres", "stress", "təzyiq", "tezyiq", "gərgin", "narahat"],
    response:
      "Dörd sanəyə içəri nəfəs al, altı sanəyə yavaşca burax. Bu dalğa yüksəlib keçəcək. Mən bu an səninlə birlikdəyəm.",
  },
  {
    key: "motivation",
    keywords: ["motiv", "güc", "yorgun", "yorğun", "tərs"],
    response:
      "Sən artıq burdasan — bunun özü böyük cəsarətdir. Bu gün nə qədər edirsən, tam kifayət edər.",
  },
];

export function matchDoctorTopic(transcript: string): DoctorTopic {
  const t = transcript.toLowerCase();
  return (
    doctorTopics.find((topic) =>
      topic.keywords.some((k) => t.includes(k.toLowerCase()))
    ) ?? doctorTopics[3]
  );
}

/* =================== CONTENT — Doktor AI və menyu =================== */
