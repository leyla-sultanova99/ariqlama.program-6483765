import {
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type ReactNode,
} from "react";
import { motion } from "framer-motion";
import { cn } from "@/utils/cn";
import { useHaptics } from "@/lib/hooks";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "outline";
  size?: "md" | "lg";
  loading?: boolean;
  haptic?: boolean;
  children: ReactNode;
}

interface Ripple {
  id: number;
  x: number;
  y: number;
  size: number;
}

export default function Button({
  variant = "primary",
  size = "md",
  loading = false,
  haptic = true,
  className,
  children,
  onClick,
  disabled,
  ...rest
}: ButtonProps) {
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const idRef = useRef(0);
  const { vibrate } = useHaptics();

  function spawn(e: React.MouseEvent<HTMLButtonElement>) {
    if (haptic) vibrate(8);
    const rect = e.currentTarget.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 1.1;
    const ripple: Ripple = {
      id: idRef.current++,
      x: e.clientX - rect.left - size / 2,
      y: e.clientY - rect.top - size / 2,
      size,
    };
    setRipples((r) => [...r, ripple]);
    window.setTimeout(() => {
      setRipples((r) => r.filter((x) => x.id !== ripple.id));
    }, 650);
  }

  return (
    <motion.button
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.94, y: 0 }}
      transition={{ type: "spring", stiffness: 420, damping: 22, mass: 0.7 }}
      onClick={(e) => {
        spawn(e);
        if (!disabled && !loading) onClick?.(e);
      }}
      disabled={disabled || loading}
      className={cn(
        "btn",
        variant === "primary" ? "btn-primary" : "btn-outline",
        size === "lg" ? "h-14 px-8 text-[16px]" : "h-12 px-6 text-[15px]",
        className
      )}
      {...(rest as React.ComponentProps<typeof motion.button>)}
    >
      {ripples.map((r) => (
        <span
          key={r.id}
          className="ripple"
          style={{ left: r.x, top: r.y, width: r.size, height: r.size }}
        />
      ))}
      {/* morphing loading indicator */}
      {loading && (
        <motion.span
          className="absolute"
          initial={{ scale: 0 }}
          animate={{ scale: 1, rotate: 360 }}
          transition={{ rotate: { duration: 0.8, repeat: Infinity, ease: "linear" }, scale: { type: "spring", stiffness: 300, damping: 18 } }}
          style={{
            width: 20,
            height: 20,
            borderRadius: "50%",
            border: "2px solid rgba(42,24,16,0.25)",
            borderTopColor: "#2a1810",
          }}
        />
      )}
      <span
        className={cn(
          "relative z-10 inline-flex items-center gap-2",
          loading && "opacity-0"
        )}
      >
        {children}
      </span>
    </motion.button>
  );
}
