import {
  createContext,
  useCallback,
  useContext,
  useState,
  type ReactNode,
} from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useHaptics } from "@/lib/hooks";

type ToastTone = "calm" | "success" | "soft";

interface ToastItem {
  id: number;
  message: string;
  emoji?: string;
  tone: ToastTone;
}

interface ToastApi {
  toast: (message: string, opts?: { emoji?: string; tone?: ToastTone }) => void;
}

const ToastContext = createContext<ToastApi | null>(null);

const TONE_STYLE: Record<ToastTone, { ring: string; glow: string }> = {
  calm: { ring: "rgba(251,206,177,0.5)", glow: "rgba(251,206,177,0.25)" },
  success: { ring: "rgba(251,206,177,0.7)", glow: "rgba(251,206,177,0.4)" },
  soft: { ring: "rgba(245,230,211,0.35)", glow: "rgba(245,230,211,0.15)" },
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const idRef = useState(() => ({ n: 0 }))[0];
  const { vibrate } = useHaptics();

  const toast = useCallback<ToastApi["toast"]>(
    (message, opts) => {
      const id = ++idRef.n;
      const item: ToastItem = {
        id,
        message,
        emoji: opts?.emoji,
        tone: opts?.tone ?? "calm",
      };
      vibrate(opts?.tone === "success" ? [10, 30, 12] : 12);
      setToasts((t) => [...t, item]);
      window.setTimeout(() => {
        setToasts((t) => t.filter((x) => x.id !== id));
      }, 3200);
    },
    [idRef, vibrate]
  );

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-20 z-[60] flex flex-col items-center gap-2 px-4">
        <AnimatePresence>
          {toasts.map((t) => {
            const s = TONE_STYLE[t.tone];
            return (
              <motion.div
                key={t.id}
                layout
                initial={{ opacity: 0, y: -26, scale: 0.86, filter: "blur(4px)" }}
                animate={{ opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -14, scale: 0.92, filter: "blur(3px)" }}
                transition={{ type: "spring", stiffness: 340, damping: 20, mass: 0.8 }}
                className="glass pointer-events-auto flex max-w-[360px] items-center gap-3 px-4 py-3"
                style={{
                  borderRadius: 22,
                  boxShadow: `0 12px 40px rgba(0,0,0,0.4), 0 0 0 1px ${s.ring}, 0 0 30px ${s.glow}`,
                }}
              >
                {t.emoji && (
                  <motion.span
                    initial={{ scale: 0.3, rotate: -28, opacity: 0 }}
                    animate={{ scale: [0.3, 1.18, 1], rotate: 0, opacity: 1 }}
                    transition={{ duration: 0.5, ease: [0.2, 1.65, 0.4, 1], delay: 0.08 }}
                    style={{ fontSize: 20 }}
                  >
                    {t.emoji}
                  </motion.span>
                )}
                <span className="text-[14px] font-semibold leading-snug text-[var(--ink)]">
                  {t.message}
                </span>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastApi {
  const ctx = useContext(ToastContext);
  if (!ctx) return { toast: () => {} };
  return ctx;
}
