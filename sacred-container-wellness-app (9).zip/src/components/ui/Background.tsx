import { motion, useScroll, useSpring, useTransform } from "framer-motion";

export default function Background() {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 800], [0, 80]);
  const y2 = useTransform(scrollY, [0, 800], [0, -50]);
  // 4 orb → 2 orb, aurora drift silindi, floatXY yalnız CSS (GPU-only)
  const sy1 = useSpring(y1, { stiffness: 40, damping: 22, mass: 1 });
  const sy2 = useSpring(y2, { stiffness: 40, damping: 22, mass: 1 });

  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden>
      {/* Gradient fon */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 120% 80% at 50% 0%, #2D1810 0%, #1A100A 40%, #0D0805 100%)",
        }}
      />

      {/* Orb 1 — yuxarı mərkəz */}
      <motion.div
        style={{ y: sy1 }}
        className="animate-floatY absolute -top-24 left-1/2 h-[380px] w-[380px] -translate-x-1/2 rounded-full opacity-45 blur-[90px]"
      >
        <div
          className="h-full w-full rounded-full"
          style={{ background: "radial-gradient(circle, rgba(245,184,149,0.45), transparent 65%)" }}
        />
      </motion.div>

      {/* Orb 2 — sağ alt */}
      <motion.div
        style={{ y: sy2 }}
        className="animate-floatY absolute bottom-0 -left-20 h-[300px] w-[300px] rounded-full opacity-30 blur-[80px]"
      >
        <div
          className="h-full w-full rounded-full"
          style={{ animationDelay: "-5s", background: "radial-gradient(circle, rgba(251,206,177,0.28), transparent 65%)" }}
        />
      </motion.div>
    </div>
  );
}
