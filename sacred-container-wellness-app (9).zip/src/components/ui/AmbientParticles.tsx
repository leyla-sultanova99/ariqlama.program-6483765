import { motion } from "framer-motion";

// Azaldılmış: 6 → 4 particle, sparkle qatı tamamilə silindi (performans)
const PARTICLES = [
  { left: 15, size: 4, dur: 8, delay: 0,   drift: 10  },
  { left: 42, size: 3, dur: 10, delay: 1.8, drift: -12 },
  { left: 68, size: 4, dur: 9,  delay: 0.9, drift: 8   },
  { left: 88, size: 3, dur: 11, delay: 3,   drift: -8  },
];

export default function AmbientParticles() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {PARTICLES.map((p, i) => (
        <motion.span
          key={i}
          className="absolute rounded-full"
          style={{
            left: `${p.left}%`,
            bottom: 0,
            width: p.size,
            height: p.size,
            background: "radial-gradient(circle, rgba(251,206,177,0.85), rgba(251,206,177,0.15))",
            willChange: "transform, opacity",
          }}
          animate={{
            y: [0, -140],
            x: [0, p.drift],
            opacity: [0, 0.75, 0],
          }}
          transition={{ duration: p.dur, repeat: Infinity, ease: "easeInOut", delay: p.delay }}
        />
      ))}
    </div>
  );
}
