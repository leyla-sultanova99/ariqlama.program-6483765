import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

interface Burst {
  id: number;
  petals: { dx: number; rot: number; delay: number; size: number; emoji: string; wobble: number }[];
  sparkles: { dx: number; dy: number; delay: number; size: number }[];
}

const PETALS = ["🌸", "🤍", "✨", "🪷", "🌿"];
const COUNT = 16;
const SPARK_COUNT = 10;

/** Imperative soft-confetti. Pass a key bump to trigger. */
export default function Confetti({ trigger }: { trigger: number }) {
  const [burst, setBurst] = useState<Burst | null>(null);

  useEffect(() => {
    if (trigger === 0) return;
    const id = trigger;
    const petals = Array.from({ length: COUNT }, (_, i) => ({
      dx: (Math.random() - 0.5) * 520,
      rot: (Math.random() - 0.5) * 720,
      delay: Math.random() * 0.35,
      size: 14 + Math.random() * 14,
      emoji: PETALS[i % PETALS.length],
      wobble: (Math.random() - 0.5) * 60,
    }));
    const sparkles = Array.from({ length: SPARK_COUNT }, () => ({
      dx: (Math.random() - 0.5) * 260,
      dy: (Math.random() - 0.5) * 180,
      delay: Math.random() * 0.25,
      size: 3 + Math.random() * 4,
    }));
    setBurst({ id, petals, sparkles });
    const t = window.setTimeout(() => setBurst(null), 2800);
    return () => window.clearTimeout(t);
  }, [trigger]);

  return (
    <div className="pointer-events-none fixed inset-0 z-[55] overflow-hidden">
      <AnimatePresence>
        {burst && (
          <div key={burst.id} className="absolute left-1/2 top-1/3 -translate-x-1/2">
            {/* quick radiant sparkle pop, underneath the falling petals */}
            {burst.sparkles.map((s, i) => (
              <motion.span
                key={`spark-${i}`}
                initial={{ opacity: 0, x: 0, y: 0, scale: 0 }}
                animate={{ opacity: [0, 1, 0], x: s.dx, y: s.dy, scale: [0, 1, 0.4] }}
                transition={{ duration: 0.9, delay: s.delay, ease: [0.22, 1, 0.36, 1] }}
                className="absolute rounded-full"
                style={{
                  width: s.size,
                  height: s.size,
                  background: "radial-gradient(circle, #fff, rgba(251,206,177,0.6))",
                  boxShadow: "0 0 8px rgba(251,206,177,0.8)",
                }}
              />
            ))}
            {burst.petals.map((p, i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0, x: 0, y: 0, scale: 0.3, rotate: 0 }}
                animate={{
                  opacity: [0, 1, 1, 0],
                  x: [0, p.dx * 0.55 + p.wobble, p.dx],
                  y: [0, 60, 360],
                  scale: [0.3, 1, 0.9],
                  rotate: [0, p.rot * 0.6, p.rot],
                }}
                transition={{
                  duration: 2.4,
                  delay: p.delay,
                  ease: [0.22, 1, 0.36, 1],
                  times: [0, 0.12, 0.7, 1],
                }}
                className="absolute"
                style={{ fontSize: p.size, filter: "drop-shadow(0 4px 10px rgba(251,206,177,0.4))" }}
              >
                {p.emoji}
              </motion.span>
            ))}
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
