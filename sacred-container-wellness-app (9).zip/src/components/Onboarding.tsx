import { useState } from "react";
import { AnimatePresence, motion, type Variants } from "framer-motion";
import Button from "@/components/ui/Button";
import { useStore, type Profile } from "@/lib/store";
import { calcCaloriesGPT } from "@/lib/calories";
import { useHaptics } from "@/lib/hooks";

interface QOption {
  value: string;
  label: string;
  emoji?: string;
}

interface Question {
  key: keyof Profile;
  eyebrow: string;
  title: string;
  reassurance: string;
  options: QOption[];
}

// ORDER: Cins → Yaş → Boy → Çəki → Aktivlik (5 sual)
const questions: Question[] = [
  {
    key: "gender",
    eyebrow: "Səni tanıyaq",
    title: "Özünü necə tanıdırdın?",
    reassurance: "Bu məlumat yalnız sənə uyğun menyunu hazırlamaq üçündür.",
    options: [
      { value: "woman", label: "Qadın", emoji: "🌸" },
      { value: "man", label: "Kişi", emoji: "🌿" },
    ],
  },
  {
    key: "age",
    eyebrow: "Yumşaq bir sual",
    title: "Hansı yaş aralığındasan?",
    reassurance: "Heç bir mühakimə yoxdur — yalnız sənə xas dəstək üçün.",
    options: [
      { value: "18-25", label: "18 – 25" },
      { value: "26-35", label: "26 – 35" },
      { value: "36-45", label: "36 – 45" },
      { value: "46-55", label: "46 – 55" },
      { value: "56+", label: "56+" },
    ],
  },
  {
    key: "height",
    eyebrow: "Bir addım da",
    title: "Boyun hansı aralıqdır?",
    reassurance: "Sənin məlumatların yalnız sənə ən yaxşı menyunu seçmək üçündür.",
    options: [
      { value: "140-160", label: "140 – 160 sm" },
      { value: "160-175", label: "160 – 175 sm" },
      { value: "175-190", label: "175 – 190 sm" },
      { value: "190+", label: "190+ sm" },
    ],
  },
  {
    key: "weight",
    eyebrow: "Şəfqətlə",
    title: "Təxmini çəki aralığın?",
    reassurance: "Bu rəqəm heç kimə görünmir, yalnız sənin menyun üçündür. Tam təhlükəsizdir.",
    options: [
      { value: "40-60", label: "40 – 60 kq" },
      { value: "60-80", label: "60 – 80 kq" },
      { value: "80-100", label: "80 – 100 kq" },
      { value: "100-120", label: "100 – 120 kq" },
      { value: "120+", label: "120+ kq" },
    ],
  },
  {
    key: "activity",
    eyebrow: "Sənin ritmin",
    title: "Gün ərzində fiziki aktivlik səviyyən necədir?",
    reassurance: "Bu, sənə ən uyğun kalori balansını tapmağa kömək edir.",
    options: [
      { value: "sedentary", label: "Yavaş — əsasən oturaq həyat tərzi", emoji: "🐢" },
      { value: "moderate", label: "Orta — gün ərzində müəyyən qədər hərəkət edirəm, normal aktivlik", emoji: "🚶" },
      { value: "active", label: "Aktiv — gün ərzində çox hərəkət edirəm və ya mütəmadi idman edirəm", emoji: "🏃" },
    ],
  },
  {
    key: "exerciseFrequency",
    eyebrow: "Hərəkət adətlərin",
    title: "Həftədə neçə gün idman edirsən?",
    reassurance: "Bu məlumat sənin həqiqi enerji sərfiyyatını daha dəqiq qiymətləndirməyə kömək edir.",
    options: [
      { value: "0", label: "0 gün" },
      { value: "1-2", label: "1 – 2 gün" },
      { value: "3-4", label: "3 – 4 gün" },
      { value: "5-6", label: "5 – 6 gün" },
      { value: "7", label: "Hər gün" },
    ],
  },
  {
    key: "exerciseType",
    eyebrow: "Nə cür hərəkət",
    title: "Əsas idman növün hansıdır?",
    reassurance: "Bu məlumat fərdi planını daha dəqiq hazırlamağa kömək edir.",
    options: [
      { value: "none", label: "İdman etmirəm", emoji: "🛋️" },
      { value: "walk", label: "Gəzinti", emoji: "🚶" },
      { value: "home", label: "Evdə məşq", emoji: "🏠" },
      { value: "gym", label: "Fitnes / ağırlıq məşqi", emoji: "🏋️" },
      { value: "cardio", label: "Qaçış / kardio", emoji: "🏃" },
      { value: "other", label: "Digər", emoji: "🤸" },
    ],
  },
  {
    key: "workLifestyle",
    eyebrow: "Günlük həyat tərzin",
    title: "Günlük iş və həyat tərzin necədir?",
    reassurance: "Bu məlumat sənin gündəlik enerji ehtiyacını dəqiq hesablamağa kömək edir.",
    options: [
      { value: "sitting", label: "Əsasən oturaq", emoji: "🪑" },
      { value: "mixed", label: "Qarışıq — həm otururam, həm hərəkət edirəm", emoji: "🔄" },
      { value: "standing", label: "Əsasən ayaqüstə", emoji: "🧍" },
      { value: "heavy", label: "Fiziki cəhətdən ağır iş", emoji: "💪" },
    ],
  },
  {
    key: "restriction",
    eyebrow: "Qida məhdudiyyətin",
    title: "Hər hansı qida məhdudiyyətin varmı?",
    reassurance: "Menyun sənin seçiminə uyğun hazırlanacaq — heç nə məcburi deyil.",
    options: [
      { value: "none", label: "Yoxdur", emoji: "✅" },
      { value: "dairy-free", label: "Süd məhsulsuz", emoji: "🥛" },
      { value: "bread-free", label: "Çörəksiz", emoji: "🍞" },
      { value: "meat-free", label: "Ətsiz (vegetarian)", emoji: "🥦" },
      { value: "egg-free", label: "Yumurtasız", emoji: "🥚" },
    ],
  },
];

// Premium easing — smooth, GPU-friendly.
const EASE = [0.25, 1, 0.5, 1] as const;

// Stagger container — orchestrates children entrance smoothly.
const containerVariants: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.06, delayChildren: 0.08 } },
};
// Each option — only opacity + y (GPU-optimal, no jank).
const itemVariants: Variants = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: EASE } },
};

export default function Onboarding() {
  const { saveProfile } = useStore();
  const { vibrate } = useHaptics();
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Partial<Profile>>({});
  const [loading, setLoading] = useState(false);

  const qIndex = step - 1;
  const q = questions[qIndex];
  const isWelcome = step === 0;
  const isStart = step === questions.length + 1;
  const total = questions.length + 1;

  function pick(value: string) {
    vibrate([8, 22, 8]);
    const updated = { ...answers, [q.key]: value } as Partial<Profile>;
    setAnswers(updated);
    window.setTimeout(() => setStep((s) => s + 1), 280);
  }

  function back() {
    vibrate(6);
    setStep((s) => Math.max(1, s - 1));
  }

  async function begin() {
    vibrate([12, 40, 16]);
    setLoading(true);

    const profile: Profile = {
      ...answers,
      gender: answers.gender ?? "woman",
      age: answers.age ?? "26-35",
      height: answers.height ?? "160-175",
      weight: answers.weight ?? "60-80",
      activity: answers.activity ?? "moderate",
      exerciseFrequency: answers.exerciseFrequency ?? "1-2",
      exerciseType: answers.exerciseType ?? "none",
      workLifestyle: answers.workLifestyle ?? "mixed",
      restriction: answers.restriction ?? "none",
    } as Profile;

    // GPT-4o ilə kalori hesabı — cache-ə yazılır, API xətasında lokal ehtiyat işləyir
    await calcCaloriesGPT(profile).catch(() => {/* lokal fallback avtomatik */});

    saveProfile(profile);
  }

  return (
    <>
      {/* ===== Loading screen ===== */}
      <AnimatePresence>
        {loading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4, ease: EASE }}
            className="fixed inset-0 z-[70] flex flex-col items-center justify-center"
            style={{ background: "rgba(15,13,11,0.92)", backdropFilter: "blur(8px)" }}
          >
            <div className="avatar-orb animate-breathe mb-8 flex h-24 w-24 items-center justify-center rounded-full">
              <span style={{ fontSize: 44 }}>🪷</span>
            </div>
            <div className="loader-dots">
              <span />
              <span />
              <span />
            </div>
            <p className="t-small mt-6 text-[var(--ink-dim)]">Sığınacağın hazırlanır…</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== Onboarding flow ===== */}
      <motion.div
        initial={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.35, ease: EASE }}
        className="fixed inset-0 z-50 flex flex-col"
      >
        {/* progress — spring-driven fill for a livelier feel (GPU-friendly, NO layout reflow) */}
        <div className="flex gap-2 px-6 pt-[max(1.5rem,env(safe-area-inset-top))]">
          {Array.from({ length: total }).map((_, idx) => (
            <div key={idx} className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/[0.07]">
              <motion.div
                className="h-full rounded-full origin-left"
                style={{
                  background: "linear-gradient(to right, var(--accent-soft), var(--accent))",
                  willChange: "transform",
                }}
                initial={false}
                animate={{ scaleX: idx < step ? 1 : 0 }}
                transition={{ type: "spring", stiffness: 260, damping: 26, mass: 0.6 }}
              />
            </div>
          ))}
        </div>

        {/* content */}
        <div className="flex flex-1 flex-col justify-center px-7">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 36, filter: "blur(3px)" }}
              animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, x: -36, filter: "blur(2px)" }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              style={{ willChange: "transform, opacity, filter" }}
              className="mx-auto flex w-full max-w-[420px] flex-col"
            >
              {isWelcome ? (
                <motion.div
                  variants={containerVariants}
                  initial="hidden"
                  animate="show"
                  className="flex flex-col items-center text-center"
                >
                  {/* Welcome orb — CSS animations (compositor thread, no JS) */}
                  <motion.div
                    variants={itemVariants}
                    className="relative flex h-40 w-40 items-center justify-center"
                  >
                    <span
                      className="animate-pulse-ring absolute rounded-full"
                      style={{
                        width: 120, height: 120,
                        border: "1px solid rgba(251,206,177,0.4)",
                        animationDelay: "0s",
                      }}
                    />
                    <span
                      className="animate-pulse-ring absolute rounded-full"
                      style={{
                        width: 120, height: 120,
                        border: "1px solid rgba(251,206,177,0.4)",
                        animationDelay: "1.5s",
                      }}
                    />
                    <div className="avatar-orb animate-breathe flex h-[120px] w-[120px] items-center justify-center rounded-full">
                      <span style={{ fontSize: 52 }}>🪷</span>
                    </div>
                  </motion.div>
                  <motion.p variants={itemVariants} className="eyebrow mt-7">Xoş gəldin!</motion.p>
                  <motion.h1 variants={itemVariants} className="t-hero text-gradient mt-2">Sənin sığınacağın</motion.h1>
                  <motion.p variants={itemVariants} className="t-body mt-4 max-w-[320px] text-[var(--ink-dim)]">
                    Burada heç bir mühakimə, heç bir təzyiq yoxdur. Yalnız sən,
                    sənin bədənin və yumşaq bir dəstək. Səni bir az tanıyaq ki, sənə
                    ən uyğun menyunu hazırlayaq.
                  </motion.p>
                  <motion.div variants={itemVariants} className="mt-8">
                    <Button size="lg" onClick={() => { vibrate(8); setStep(1); }} className="min-w-[180px]">
                      Başlayaq <span style={{ fontSize: 18 }}>→</span>
                    </Button>
                  </motion.div>
                </motion.div>
              ) : isStart ? (
                <motion.div
                  variants={containerVariants}
                  initial="hidden"
                  animate="show"
                  className="flex flex-col items-center text-center"
                >
                  <motion.div
                    variants={itemVariants}
                    className="avatar-orb animate-breathe flex h-24 w-24 items-center justify-center rounded-full"
                  >
                    <span style={{ fontSize: 44 }}>🤍</span>
                  </motion.div>
                  <motion.h1 variants={itemVariants} className="t-hero text-gradient mt-6">Hazırsan</motion.h1>
                  <motion.p variants={itemVariants} className="t-body mt-3 max-w-[300px] text-[var(--ink-dim)]">
                    Səni tanıdıq. İndi sənin üçün xüsusi bir menyu hazırlaya bilərik.
                    Sığınacağın qapısı tam açıqdır.
                  </motion.p>
                  <motion.div variants={itemVariants} className="mt-8">
                    <Button size="lg" onClick={begin} className="min-w-[200px]">
                      BAŞLA
                    </Button>
                  </motion.div>
                  <motion.button
                    variants={itemVariants}
                    whileHover={{ x: -3 }}
                    onClick={back}
                    className="mt-6 text-[13px] font-medium text-[var(--ink-dim)] hover:text-[var(--accent)]"
                  >
                    ← Geri qayıt
                  </motion.button>
                </motion.div>
              ) : (
                <div>
                  <p className="eyebrow">{q.eyebrow}</p>
                  <h1 className="mt-2 text-[24px] font-extrabold leading-tight tracking-tight text-[var(--ink)]">
                    {q.title}
                  </h1>
                  <p className="t-small mt-2 text-[var(--ink-dim)]">{q.reassurance}</p>

                  {/* options — staggered entrance via variants (GPU-friendly) */}
                  <motion.div
                    variants={containerVariants}
                    initial="hidden"
                    animate="show"
                    className={`mt-6 grid gap-3 ${q.options.length === 2 ? "grid-cols-2" : "grid-cols-1"}`}
                  >
                    {q.options.map((opt) => {
                      const selected = answers[q.key] === opt.value;
                      return (
                        <motion.button
                          key={opt.value}
                          variants={itemVariants}
                          whileHover={{ y: -4, scale: 1.015 }}
                          whileTap={{ scale: 0.96, y: 0 }}
                          transition={{ type: "spring", stiffness: 380, damping: 22 }}
                          onClick={() => pick(opt.value)}
                          className="glass relative flex items-center gap-3 p-4 text-left"
                          style={{
                            borderRadius: 20,
                            background: selected
                              ? "linear-gradient(135deg, rgba(251,206,177,0.22), rgba(245,184,149,0.06))"
                              : undefined,
                            boxShadow: selected
                              ? "inset 0 0 0 1.5px rgba(251,206,177,0.6), 0 12px 30px rgba(251,206,177,0.16)"
                              : undefined,
                          }}
                        >
                          {opt.emoji && <span style={{ fontSize: 26 }}>{opt.emoji}</span>}
                          <span
                            className="text-[15px] font-semibold"
                            style={{ color: selected ? "var(--accent)" : "var(--ink)" }}
                          >
                            {opt.label}
                          </span>
                          {selected && (
                            <motion.span
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ type: "spring", stiffness: 320, damping: 16 }}
                              className="ml-auto flex h-6 w-6 items-center justify-center rounded-full text-[14px] font-bold"
                              style={{
                                background: "linear-gradient(135deg, var(--accent), var(--accent-soft))",
                                color: "#2a1810",
                              }}
                            >
                              ✓
                            </motion.span>
                          )}
                        </motion.button>
                      );
                    })}
                  </motion.div>

                  {/* back button */}
                  {step > 1 && (
                    <button
                      onClick={back}
                      className="mt-6 text-[13px] font-medium text-[var(--ink-dim)] transition-colors hover:text-[var(--accent)]"
                    >
                      ← Geri qayıt
                    </button>
                  )}
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.div>
    </>
  );
}
